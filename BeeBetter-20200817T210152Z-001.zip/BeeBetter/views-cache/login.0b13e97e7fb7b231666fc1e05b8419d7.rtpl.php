<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />
    <meta charset="UTF-8">
    <title>Acesso ao Portal</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/login/login.css">
    
</head>
<body>

    <?php require $this->checkTemplate("navbar");?>
    <p style="margin-top: 30px;"></p>

    <div id="container">
            
        <div class="form-login">

            <p id="titulo"> <b>Área Institucional</b> </p>

            <label>Login</label>
            <input type="text" class="form-control form-field" id="field-login" tabindex="1" autofocus>
            <span class="span-error" id="span-error-login"> Preencha este campo.</span>

            <label>Senha</label>
            <input type="password" class="form-control form-field" id="field-senha" tabindex="3">
            <span class="span-error" id="span-error-senha"> Preencha este campo.</span>

            <p class="esqueceu-senha" id="esqueceu-senha" onclick="modalEsqueceuSenha()"><b>Esqueceu a Senha?</b></p>

            <div id="div-entrar">
                <button type="button" class="btn botaoevent" tabindex="3" onclick="logar()"><b>Entrar</b></button>
            </div>

            <p class="wrong-passord" id="error-login">Login ou Senha incorretos.</p>

        </div> 

       
        <a href="/BeeBetter/cadastro"> <p class="link"> Deseja cadastrar sua Instituição? Acesse! </p> </a> 
       

    </div>

    <!-- Modal Esqueceu Senha -->
    <div id="modal-forget-password" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <p id="modal-title">Recuperar Senha</p>
            </div>
            <div class="modal-body">
                <div class="recover-password" id="recover-password">
                    <label>Digite o email vinculado a conta que você deseja recuperar:</label>
                    <input type="text" class="form-control form-field" id="field-rec-email" tabindex="1" placeholder="SeuEmail@gmail.com">              
                    <span class="span-error" id="span-error-rec-email"> Preencha este campo.</span>
                    <div class="div-buttons-modal">
                        <hr>
                        <button type="button" class="btn" id="btn-cancel-pass">Cancelar</button>
                        <button type="button" class="btn" id="btn-send-pass">Confirmar</button>
                    </div> 
                </div>
                <div class="recover-msg-success" id="recover-msg-success">
                    <div class="modal-body">
                        <p>Um email de recuperação foi enviado para: <b id="nome-email">exemplo@gmail.com</b></p>
                        <div class="div-buttons-modal">
                            <hr>
                            <button type="button" class="btn" id="btn-end-pass">Entendi</button>
                        </div>
                    </div> 
                </div> 
            </div>
        </div>

    </div>

    <p style="margin-top: 30px;"></p>

    <?php require $this->checkTemplate("footer");?>

</body>

<script src="/BeeBetter/src/backend/ajax.js"></script>
<script src="/BeeBetter/src/login/login.js"></script>
</html>