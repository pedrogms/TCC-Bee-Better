<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sua Conta | BeeBetter</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/conta/conta.css">
    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />

</head>
<body>

    <?php require $this->checkTemplate("navbar");?>

    <p style="margin-top: 30px;"></p>
    
    <div class="container">

        <div class="row main-page" id="main-page">

            <!---------------- Informações Sobre a Conta ---------------->
            <div class="col-3 acc-info-display">

                <div class="row acc-div-photo">
                    <img src="#" id="acc-photo"></img>
                </div>
                <p id="acc-p-edit-photo">Alterar Foto Principal
                    <img src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2F483923.svg?alt=media&token=b60242f3-288e-4408-9354-aee48abd1ae0" alt="Editar Foto" id="acc-edit-icon">
                </p>
                
            </div>

            <!---------------- Menu de Configurações ---------------->
            <div class="col-8 config-display">

                <p class="config-menu-title" id="titulo">Bem-vindo(a) Usuário</p>

                <div class="row config-menu">

                    <ul class="config-menu-option-ul">
                        <li class="config-menu-option-li" id="li-item-perfil" onclick="toggleConfigOption(0)">Meus Dados</li>
                        <li class="config-menu-option-li" id="li-item-messages" onclick="toggleConfigOption(1)">Postagens</li>
                        <li class="config-menu-option-li" id="li-item-send-image" onclick="toggleConfigOption(2)">Imagens</li>
                        <li class="config-menu-option-li" id="li-item-security" onclick="toggleConfigOption(3)">Segurança</li>
                        <li class="config-menu-option-li" id="li-item-others" onclick="toggleConfigOption(4)">Outros</li>
                    </ul>
                </div>

                <hr id="config-menu-hr">

                <div class="config-main">
                    
                    <!---------------------------- ABA MEUS DADOS ------------------------------>
                    <div id="config-main-profile">  

                        <div class="row config-inner-profile-elements">
                            <div class="col-6">
                                <p class="config-main-subtitle">Meus Dados</p>  
                            </div>
                            <div class="col-6">
                                <div class="row d-flex flex-row-reverse edit-buttons">
                                    <button id="config-main-edit-data" onclick="salvarAlteracoesPerfil()">Alterar Dados</button>
                                    <button id="config-main-cancel-edit" style="display:none">Cancelar</button>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <!------------ Menu de Opções de Dados ------------>
                            <div class="col-2">
                                <p class="config-select-configuration config-select-configuration-selected" id="config-submenu-geral" onclick="selecionarConfiguracao(0)">Geral</p>
                                <p class="config-select-configuration" id="config-submenu-endereco" onclick="selecionarConfiguracao(1)">Endereço</p>
                                <p class="config-select-configuration" id="config-submenu-contato" onclick="selecionarConfiguracao(2)">Contato</p>
                                <p class="config-select-configuration" id="config-submenu-redes-sociais" onclick="selecionarConfiguracao(3)">Redes Sociais</p>
                            </div>

                            <div class="col-10">
                                <!-- Geral -->
                                    <div class="config-main-box" id="config-profile-geral">
                                    <p class="config-main-box-title">Geral</p>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label" class="config-main-label">Nome / Razão Social</label>
                                            <input type="text" class="form-control form-field" id="profile-razao-social" placeholder="Sem informações">
                                            <span class="span-error" id="span-error-profile-razao-social"> Preencha este campo.</span>
                                        </div>
                                        <div class="col-6">
                                            <label class="config-main-label">CNPJ</label>
                                            <input type="text" class="form-control form-field" id="profile-cnpj" placeholder="Adicione um cnpj" maxlength="14" onkeypress="return isNumberKey(event)">
                                            <span class="span-error" id="span-error-profile-cnpj">Número de CNPJ inválido!</span>
                                        </div>
                                    </div>
                                
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label">Causa Social</label>
                                            <select class="form-control form-field" id="profile-causa-social">
                                                <option selected disabled>Causa Social</option>
                                                <option>Assistência a Animais</option>
                                                <option>Assistência a Crianças</option>
                                                <option>Assistência Educacional</option>
                                                <option>Assistência Financeira</option>
                                                <option>Assistêcia Médica</option>
                                                <option>Auxílio a Moradores de Rua</option>
                                                <option>Doação de Roupas</option>
                                                <option>Doação de Alimentos</option>
                                                <option>Proteção Ambiental</option>
                                            </select>

                                            <span class="span-error" id="span-error-causa-social">Preencha este campo.</span>
                                        </div>
                                        <div class="col-6">
                                            <label class="config-main-label">Email Cadastrado</label>
                                            <input type="text" class="form-control form-field" id="profile-email" placeholder="Sem informações">
                                            <span class="span-error" id="span-error-profile-email">Preencha este campo.</span>
                                        </div>
                                    </div>

                                    <div class="row"> 
                                        <div class="col-12">
                                            <label class="config-main-label" title="Utilize o campo abaixo para descrever sua ONG. História, fundadores, atividades recentes, etc">Descrição de sua ONG</label>
                                            <textarea class="form-control form-field" id="profile-descricao" rows="8"></textarea>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Endereço -->
                                <div class="config-main-box" id="config-profile-endereco" style="display: none">
                                    <p class="config-main-box-title">Endereço</p>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label">CEP</label>
                                            <input type="text" class="form-control form-field" id="profile-cep" placeholder="Sem informações" maxlength="8" onkeypress="return isNumberKey(event)">
                                            <span class="span-error" id="span-error-profile-cep">Preencha este campo.</span>
                                        </div>
                                        <div class="col-6">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label">Rua</label>
                                            <input type="text" class="form-control form-field" id="profile-rua" placeholder="Sem informações" maxlength="50">
                                            <span class="span-error" id="span-error-profile-rua">Preencha este campo.</span>
                                        </div>
                                        <div class="col-4">
                                            <label class="config-main-label">Bairro</label>
                                            <input type="text" class="form-control form-field" id="profile-bairro" placeholder="Sem informações"maxlength="50">
                                            <span class="span-error" id="span-error-profile-bairro">Preencha este campo.</span>
                                        </div>
                                        <div class="col-2">
                                            <label class="config-main-label">Número</label>
                                            <input type="text" class="form-control form-field" id="profile-numero" placeholder="" maxlength="5" onkeypress="return isNumberKey(event)">  
                                            <span class="span-error" id="span-error-profile-numero">Preencha este campo.</span>                                         
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-5">
                                            <label class="config-main-label">Cidade</label>
                                            <input type="text" class="form-control form-field" id="profile-cidade" placeholder="Sem informações" maxlength="50">
                                            <span class="span-error" id="span-error-profile-cidade">Preencha este campo.</span>
                                        </div>
                                        <div class="col-3">
                                            <label class="config-main-label">UF</label>
                                            <select class="form-control form-field" id="profile-uf" onchange="writeUF(this.value)">
                                            <option selected disabled>UF</option>
                                                <option>AC</option>
                                                <option>AL</option>
                                                <option>AP</option>
                                                <option>AM</option>
                                                <option>BA</option>
                                                <option>CE</option>
                                                <option>DF</option>
                                                <option>ES</option>
                                                <option>GO</option>
                                                <option>MA</option>
                                                <option>MT</option>
                                                <option>MS</option>
                                                <option>MG</option>
                                                <option>PA</option>
                                                <option>PB</option>
                                                <option>PR</option>
                                                <option>PE</option>
                                                <option>PI</option>
                                                <option>RJ</option>
                                                <option>RN</option>
                                                <option>RS</option>
                                                <option>RO</option>
                                                <option>RR</option>
                                                <option>SC</option>
                                                <option>SP</option>
                                                <option>SE</option>
                                                <option>TO</option>
                                            </select>
                                        </div>
                                        <div class="col-4">
                                            <label class="config-main-label">Estado</label>
                                            <input type="text" class="form-control form-field" id="profile-estado" placeholder="Sem informações">
                                        </div>
                                    </div>
                                </div>

                                <!-- Contato -->
                                <div class="config-main-box" id="config-profile-contato" style="display: none">
                                    <p class="config-main-box-title">Contato</p>

                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label">Telefone Fixo</label>
                                            <input type="text" class="form-control form-field" id="profile-fone-fixo" placeholder="Sem informações" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                            <span class="span-error" id="span-error-profile-fone-fixo">Preencha este campo.</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-6">
                                            <label class="config-main-label">WhatsApp </label>
                                            <input type="text" class="form-control form-field" id="profile-whatsapp1" placeholder="Sem informações" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                            <span class="span-error" id="span-error-profile-whatsapp1">Preencha este campo.</span>
                                        </div>

                                        <div class="col-6">
                                        
                                            <label class="config-main-label">WhatsApp 2</label>
                                            <input type="text" class="form-control form-field" id="profile-whatsapp2" placeholder="Sem informações" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                            <span class="span-error" id="span-error-profile-whatsapp2 ">Preencha este campo.</span>
                                        </div>

                                    </div>
                                </div>

                                <!-- Redes Sociais -->
                                <div class="config-main-box" id="config-profile-redes-sociais" style="display: none">
                                    <p class="config-main-box-title">Suas Redes Sociais</p>
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="config-main-label">Facebook</label>
                                            <input type="text" class="form-control form-field" id="profile-facebook" placeholder="Insira a URL que leva a sua página do Facebook">
                                            <span class="span-error" id="span-error-profile-facebook">URL inválida.</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12">
                                            <label class="config-main-label">Instagram</label>
                                            <input type="text" class="form-control form-field" id="profile-instagram" placeholder="Insira a URL que leva a sua página do Instagram">
                                            <span class="span-error" id="span-error-profile-instagram">URL inválida.</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12">
                                            <label class="config-main-label">Twitter</label>
                                            <input type="text" class="form-control form-field" id="profile-twitter" placeholder="Insira a URL que leva a sua página do Twitter">
                                            <span class="span-error" id="span-error-profile-twitter">URL inválida.</span>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12">
                                            <label class="config-main-label">Youtube</label>
                                            <input type="text" class="form-control form-field" id="profile-youtube" placeholder="Insira a URL que leva a sua página do Youtube">
                                            <span class="span-error" id="span-error-profile-youtube">URL inválida.</span>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <!---------------------------- ABA POSTAGENS ------------------------------>
                    <div id="config-main-messages" style="display: none">
                        <div class="row config-inner-profile-elements post-section-top">
                           
                            <p class="config-main-subtitle">Postagens</p>  

                            <div class="post-filter">
                                <span>Organizar por:</span>
                                <select class="post-select">
                                    <optgroup label="Data">
                                        <option>Mais Recente</option>  
                                        <option>Mais Antiga</option>  
                                    </optgroup>
                                    <optgroup label="Comentários">
                                        <option>Maior Número</option>
                                        <option>Menor Número</option>
                                    </optgroup>
                                    <optgroup label="Alfabético">
                                        <option>A-Z</option>
                                        <option>Z-A</option>
                                    </optgroup>
                                </select>
                            </div>
                            
                            <button class="post-btn-new-post" id="btn-nova-postagem" onclick="">Nova Postagem</button>
                                                                            
                        </div>

                        <!-- Append postagem -->
                        <div class="post-main" id="div-post-main">

                            <!-- Modelo para postagem
                            <div class="post-init">
                                <div class="post-spoiler">
                                    <p class="spoiler-title" id="post-">Fim da linha para aqueles que têm fomemagsada comloquie um e dois texto valore</p>
                                    <p class="spoiler-text">Texto da postagem parece que engenhaia de sistema de e texte de dsiteam qua valida a parte ada coisa que sele</p>
                                </div>
                                <p class="spoiler-post-data">02/06/2020</p>
                                <p><span id="spoiler-commentary-number">0</span> comentários</p>
                                <p class="post-delete-icon" title="Excluir Postagem"><img src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fnew-delete.svg?alt=media&token=f8819141-dbb2-4081-8753-585bf8faedc2"></p>
                            </div> -->

                        </div>

                        <div class="post-none">
                            <p>Nenhuma Postagem</p>
                        </div>

                        <!-- Detalhes da Postagem -->
                        <div class="detail-post">
                            <span class="detail-btn-return" id="voltar-detalhe">Voltar</span>
                            <div class="detail-content">
                                <p class="detail-post-title" id="detail-post-title">Fim da linha para aqueles que têm fome</p>
                                <div class="detail-post-text" id="detail-post-text">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam minima consequuntur eligendi nulla alias architecto expedita voluptas dolor in illo possimus ratione quod dolore corporis, sapiente nam ea maxime ullam?
                                </div>
                            </div>

                            <span class="detail-span">Comentários</span>
                            
                            <div id="append-commentary">

                                <!-- Modelo para comentário
                                <div class="comment-block">
                                    <div class="com-top">
                                        <span id="com-author">Pedro Henrique Ferreti de Souza</span>
                                        <span id="com-date-time">28/05/2020 18:40</span>
                                    </div>
                                    <div id="com-text">
                                        Adorei sua ong. Vou ajudar!
                                    </div>
                                </div> -->
                            </div>

                            <div class="comment-none">
                                <p>Nenhum Comentário</p>
                            </div>

                        </div>

                        <!-- Nova Postagem -->
                        <div class="new-post">
                            <span class="detail-btn-return" id="voltar-nova-postagem">Voltar</span>

                            <div class="new-post-main">
                                <label class="config-main-label">Título da postagem</label>
                                <input type="text" class="form-control default-inputs" id="post-titulo" maxlength="95">
                                <span class="span-error" id="span-error-post-titulo">Preencha este campo.</span>

                                <label class="config-main-label">Conteúdo</label>
                                <textarea type="text" class="form-control default-inputs" rows="10" id="post-conteudo" maxlength="65000"></textarea>
                                <span class="span-error" id="span-error-post-conteudo">Preencha este campo.</span>
                            </div>

                            <button class="post-btn-new-post" onclick="inserirPostagem()">Postar</button>
                        </div>

                    </div>

                    <!---------------------------- ABA ENVIAR IMAGEM ------------------------------>
                    <div id="config-main-send-image" style="display: none">

                        <div class="row">
                            <div class="col-6">
                                <p class="config-main-subtitle">Suas Imagens </p>   
                            </div>
                            <div class="col-6 d-flex justify-content-end" style="display: none">
                                <button id="send-delete-btn" onclick="deletarImagem()">Deletar Imagem</button>
                            </div>
                        </div>
                                                
                        <input type="file" id="send-input-upload" style="display: none" onchange="uploadImagemGaleria()">

                        <!-- Quadrinhos para imagens -->
                        <div>
                            <div class="row send-image-grid">
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-0" src="">
                                    <div class="send-empty-space" id="send-empty-up-0" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-1" src="">
                                    <div class="send-empty-space" id="send-empty-up-1" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-2" src="">
                                    <div class="send-empty-space" id="send-empty-up-2" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>                            
                            </div>
                            <div class="row send-image-grid">
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-3" src="">
                                    <div class="send-empty-space" id="send-empty-up-3" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-4" src="">
                                    <div class="send-empty-space" id="send-empty-up-4" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-5" src="">
                                    <div class="send-empty-space" id="send-empty-up-5"  style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                            </div>
                            <div class="row send-image-grid">
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-6" src="">
                                    <div class="send-empty-space" id="send-empty-up-6" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-7" src="">
                                    <div class="send-empty-space" id="send-empty-up-7" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <img class="send-image-displayer" id="send-image-8" src="">
                                    <div class="send-empty-space" id="send-empty-up-8" style="display:none">
                                        <p class="send-empty-text">Espaço vazio. Clique para fazer upload de imagem</p>
                                        <img class="send-empty-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fcloud.svg?alt=media&token=f09531f3-ba29-4064-b2c4-2def0c9c4f7a">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!---------------------------- ABA SEGURANÇA ------------------------------>
                    <div id="config-main-security" style="display: none">
                        <p class="config-main-subtitle">Proteção e Segurança</p>
                        
                        <div class="config-main-box col-8">

                            <p class="config-main-box-title">Trocar Senha</p>

                            <label class="config-main-label">Senha Atual</label>
                            <input type="password" class="form-control default-inputs" id="profile-senha-atual" maxlength="50">
                            <span class="span-error" id="span-error-senha-atual">Preencha este campo.</span>
                        
                            <label class="config-main-label">Nova Senha</label>
                            <input type="password" class="form-control default-inputs" id="profile-nova-senha" maxlength="50">
                            <span class="span-error" id="span-error-nova-senha" >Preencha este campo.</span>
                            
                            <label class="config-main-label">Confirmar Nova Senha</label>
                            <input type="password" class="form-control default-inputs" placeholder="Sua senha deve ser segura" id="profile-conf-nova-senha" maxlength="50">
                            <span class="span-error" id="span-error-conf-nova-senha">Preencha este campo.</span>
                            
                            <button class="mb-4" id="config-main-edit-data" onclick="salvarAlteracaoSenha()">Trocar Senha</button>                                 
                        </div>
                    </div>

                    <!---------------------------- ABA OUTROS ------------------------------>
                    <div id="config-main-others" style="display: none">
                        <p class="config-main-subtitle">Outros</p>

                        <div class="config-main-box col-8">
                            <p class="config-main-box-title">Desativar Conta</p>
                            <p class="others-default-text">Ao desativar sua conta, a instituição não será mais mostrada em operações de busca de outros usuários. Você pode reativar
                            sua conta a qualquer momento, voltando nesta aba e clicando no botão "Reativar Conta".</p>
                            <p id="status-conta">Sua conta está Ativada!</p>
                            
                            <label class="config-main-label">Senha</label>
                            <input type="password" class="form-control default-inputs" id="profile-senha-desativar" maxlength="50">
                            <span class="span-error" id="span-error-profile-senha-desativar">Preencha este campo.</span>
                            
                            <label class="config-main-label">Confirmar Senha</label>
                            <input type="password" class="form-control default-inputs" id="profile-conf-senha-desativar" maxlength="50">
                            <span class="span-error" id="span-error-profile-conf-senha-desativar">Preencha este campo.</span>
                            <button class="mb-4" id="config-main-edit-data" onclick="desativarCadastro()">Desativar</button>                              
                            <button class="mb-4" id="config-main-edit-data" onclick="reativarCadastro()">Reativar</button>                              
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
    </div>

    </div>


    <!------ Modal Alterar Foto de Perfil ------>
    <div class="modal" id="modalChangePhoto">
        <div class="modal-content">
            <div class="modal-header">
                <div id="modal-ong-name">Alterar Foto de Perfil</div>
                <span class="modal-span-close" id="acc-span-close">&times;</span>
            </div>
            <div class="modal-body">
                <div class="modal-change-inner-body">
                    
                    <p>A foto de perfil é aquela que será mostrada para os usuários que pesquisarem por sua ONG. Também aparecerá nos ícones de resposta de sua ONG. Portanto, escolha com cuidado!</p>
                    
                    <div class="row d-flex justify-content-center">
                        <img class="acc-modal-image-preview" id="img-preview" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fno-image.jpg?alt=media&token=b225f1cf-fac8-44b0-98fd-320cb904d004">
                    </div>
                    <div class="row d-flex justify-content-around">
                        <button class="acc-modal-btn-choose-photo" onclick="document.getElementById('input-file').click()">Escolher Foto</button>
                        <button class="acc-modal-btn-choose-photo" onclick="alterarFotoPerfil()">Salvar</button>
                        <input type="file" style="display:none" id="input-file" onchange="imgPreview()"/>
                    </div>
                </div>

            <div class="modal-footer">
               <button class="acc-modal-btn-close-modal" id="acc-btn-close-modal">Fechar</button>
            </div>
        </div>
    </div>

    <p style="margin-top: 30px;"></p>
    <?php require $this->checkTemplate("footer");?>

</body>

    <script src="https://www.gstatic.com/firebasejs/7.14.2/firebase-app.js"></script> <!-- Firebase  -->
    <script src="https://www.gstatic.com/firebasejs/7.14.2/firebase-storage.js"></script>

    <script src="/BeeBetter/src/backend/ajax.js"></script>
    <script src="/BeeBetter/src/conta/conta.js"></script>

</html>