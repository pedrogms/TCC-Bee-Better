<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/instituicao/main.css">

    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />

    <title>Faça uma Doação | BeeBetter</title>
</head>
<body>

    <?php require $this->checkTemplate("navbar");?>
    <p style="margin-top: 30px;"></p>

    <div class="bar-title">
        <p>A Ajuda Não Pode Parar</p>
    </div>

    <div class="wrap-main">

        <div class="container">

            <!------------ Instituições em Destaque ------------->
            <div class="row d-flex flex-column">
                <p class="page-subtitle">Instituições em destaque</p>
                <div class="row row-height-control" id="row-cards">

                    <!-- Modelo Padrão para Card Destaque -->
                    <!-- <div class="destaque-card">
                        <div class="destaque-img">
                            <img src="https://img.itdg.com.br/tdg/images/blog/uploads/2019/05/deixar-o-sorvete-caseiro-mais-cremoso.jpg">
                        </div>
                        <hr>
                        <div class="card-text destaque-nome-inst">Nome da instituição</div>
                        <div class="card-text destaque-local-inst">Unidade Federativa</div>
                        <div class="card-text destaque-causa-inst" title="Causa Social">Arrecadação de Alimentos</div>
                    </div> -->
                    
                </div>
            </div>

            <!------------ Encontre por Causa Social ------------->
            <div class="row d-flex flex-column mt-3">
                <p class="page-subtitle">Encontre por causa social</p>
                <div class="row m-0">
                    <div class="find-social-cause-card">Assistência a Animais</div>
                    <div class="find-social-cause-card">Assistência a Crianças</div>
                    <div class="find-social-cause-card">Assistência Educacional</div>
                    <div class="find-social-cause-card">Assistência Financeira</div>
                    <div class="find-social-cause-card">Assistêcia Médica</div>
                    <div class="find-social-cause-card">Auxílio a Moradores de Rua</div>
                    <div class="find-social-cause-card">Doação de Roupas</div>
                    <div class="find-social-cause-card">Doação de Alimentos</div>
                    <div class="find-social-cause-card">Proteção Ambiental</div>
                </div>
            </div>
        

            <!------------ Últimas Instituições ------------->
            <div class="row d-flex flex-column" style="margin-top: 30px;">
                <p class="page-subtitle">Últimos Cadastros</p>
                <div class="row row-height-control" id="row-cards-lasts">

                    
                </div>
            </div>

        </div>

            <!------------ Propaganda de Cadastro de Instituição ------------->
            <div class="ad-register-ong">
                <div class="row">
                    <div class="col-6">
                        <p class="ad-title">QUE TAL CADASTRAR SUA INSTITUIÇÃO?</p>
                        <p class="ad-explanation">Ganhe visibilidade, parceiros e ajuda em todo o país! Amplie sua área de atuação ao se cadastrar no site. </p>
                    </div>
                    <div class="col-6 d-flex">
                        <button class="ad-button" onclick="window.location.href='/BeeBetter/cadastro'">QUERO AUMENTAR MINHA DIVULGAÇÃO</button>
                    </div>

                </div>
                
            </div>

        

        <p style="margin-top: 30px;"></p>
        <?php require $this->checkTemplate("footer");?>

    </div>

    <script src="/BeeBetter/src/backend/ajax.js"></script>
    <script src="/BeeBetter/src/instituicao/main.js"></script>

</body>
</html>