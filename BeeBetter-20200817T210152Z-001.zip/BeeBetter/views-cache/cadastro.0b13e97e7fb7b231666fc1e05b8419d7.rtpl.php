<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html>

<head>
    <title>Cadastre sua ONG</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="../../components/navbar/css/navbar.css">
    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/cadastro/cadastro.css">

    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />
    
    
</head>
<body>

    <?php require $this->checkTemplate("navbar");?>

    <p style="margin-top: 30px;"></p>

    <div class="container">
        <div class="main-page">
            <p id="titulo"> CADASTRE SUA INSTITUIÇÃO</p>

            <div class="form-cadastro">

                <label>Progresso do seu cadastro:</label>
                <div class="progress">
                    <div class="progress-bar progress-bar-success" id="register-progress" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" 
                    style="width: 0%; background-color: purple;">0%</div>
                </div>        

                <p id="text-info">Cadastrar sua Instituição em nosso site é simples e rápido! Para começar, digite o nome da sua ONG.</p>

                <div class="alert alert-danger alert-dismissible mensagem-erro" id="erro-conexao" role="alert">
                    <button type="button" id="close-error-message" class="close" data-dismiss="alert" aria-label="Close" onclick="alerta(false)">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <strong>Ops! Algo deu errado ao finalizar seu cadastro. </strong> <br>
                    Tente novamente mais tarde .
                </div>

            </div>
                <!-- CADASTRO PARTE 1 -->
                <div class="form-cadastro step-1" style="display: block;">

                    <label>Nome da Instituição / Razão Social*</label>
                    <input type="text" class="form-control form-field" id="field-razaoSocial" tabindex="1" maxlength="50">
                    <span class="span-error" id="span-error-nome"> Preencha este campo.</span>

                    <label>CNPJ (se houver)</label>
                    <input type="text" class="form-control form-field" id="field-cnpj" tabindex="2" maxlength="14" onkeypress="return isNumberKey(event)">
                    <span class="span-error" id="span-error-cnpj">Número de CNPJ inválido!</span>

                    <p id="field-ob">*Campo Obrigatório</p>

                    <div class="div-botoes">
                        <button type="button" class="btn" id="btn-toggle" tabindex='3' onclick="toggleForm(2)">Próximo</button>
                    </div>
                </div> 

                <!-- CADASTRO PARTE 2 -->
                <div class="form-cadastro step-2" style="display: none;">

                    <div class="col-md-12">
                        <div class="row">
                                <label>Qual a causa social de sua Ong?*</label>
                                <select class="form-control form-field" id="field-causa-social" tabindex='4'>
                                    <option selected disabled>Causa Social</option>
                                    <option>Assistência a Animais</option>
                                    <option>Assistência a Crianças</option>
                                    <option>Assistência Educacional</option>
                                    <option>Assistência Financeira</option>
                                    <option>Assistêcia Médica</option>
                                    <option>Auxílio a Moradores de Rua</option>
                                    <option>Doação de Roupas</option>
                                    <option>Doação de Alimentos</option>
                                    <option>Proteção Ambiental</option>
                                </select>
                                <span class="span-error" id="span-error-causa-social">Preencha este campo.</span>
                            
                        </div>
                    </div>

                    <label>CEP*</label>
                    <input type="text" class="form-control form-field" id="field-cep" tabindex="5" maxlength="8" onkeypress="return isNumberKey(event)">
                    <span class="span-error" id="span-error-cep">Preencha este campo.</span>
                    <img src="https://media3.giphy.com/media/52qtwCtj9OLTi/giphy.gif?cid=790b76110fd4e7a306e06ccca74e815fce2c9e4e53a3f56d&rid=giphy.gif" id="cep-loading-gif">
                    <div class="row">
                        <div class="col-md-9">
                            <label>Rua*</label>
                            <input type="text" class="form-control form-field" id="field-rua" tabindex="6" maxlength="50">
                            <span class="span-error" id="span-error-rua">Preencha este campo.</span>
                        </div>
                        <div class="col-md-3">
                            <label>Número*</label>
                            <input type="text" class="form-control form-field" id="field-numero" tabindex="7" onkeypress="return isNumberKey(event)" maxlength="5">
                            <span class="span-error" id="span-error-numero">Preencha este campo.</span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Bairro*</label>
                            <input type="text" class="form-control form-field" id="field-bairro" tabindex="8" maxlength="50">
                            <span class="span-error" id="span-error-bairro">Preencha este campo.</span>
                        </div>
                        <div class="col-md-6">
                            <label>Cidade*</label>
                            <input type="text" class="form-control form-field" id="field-cidade" tabindex="9" maxlength="50">
                            <span class="span-error" id="span-error-cidade">Preencha este campo.</span>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-3">
                            <label>UF*</label>
                            <select type="text" class="form-control form-field" id="field-uf"tabindex="10" onchange="writeUF(this.value)">
                                <option selected disabled>UF</option>
                                <option>AC</option>
                                <option>AL</option>
                                <option>AP</option>
                                <option>AM</option>
                                <option>BA</option>
                                <option>CE</option>
                                <option>DF</option>
                                <option>ES</option>
                                <option>GO</option>
                                <option>MA</option>
                                <option>MT</option>
                                <option>MS</option>
                                <option>MG</option>
                                <option>PA</option>
                                <option>PB</option>
                                <option>PR</option>
                                <option>PE</option>
                                <option>PI</option>
                                <option>RJ</option>
                                <option>RN</option>
                                <option>RS</option>
                                <option>RO</option>
                                <option>RR</option>
                                <option>SC</option>
                                <option>SP</option>
                                <option>SE</option>
                                <option>TO</option>
                            </select>
                            <span class="span-error" id="span-error-uf">Preencha este campo.</span>
                        </div>
                        <div class="col-md-9">
                            <label>Estado</label>
                            <input type="text" class="form-control form-field" id="uf-name" disabled="true">
                        </div>
                    </div>

                    <p id="field-ob">*Campo Obrigatório</p>

                    <div class="div-botoes">
                       
                        <button type="button" class="btn" id="btn-toggle" tabindex='11' onclick="toggleForm(1)">Anterior</button>

                        <button type="button" class="btn" id="btn-toggle" tabindex='12' onclick="toggleForm(3)">
                        Próximo
                        </button>
                        

                    </div>
                </div>

                <!-- CADASTRO PARTE 3 -->
                <div class="form-cadastro step-3" style="display: none;">

                    <label>Email*</label>
                    <input type="email" class="form-control form-field" id="field-email" tabindex="13"/>
                    <span class="span-error" id="span-error-email">Preencha este campo.</span>

                    <label>Telefone Fixo</label>
                    <input type="text" class="form-control form-field" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);" id="field-fone-fixo" tabindex='14'>
                    <span class="span-error" id="span-error-fone-fixo">Preencha este campo.</span>

                    <label>WhatsApp</label>
                    <input type="text" class="form-control form-field" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);" id="field-whatsapp" tabindex='15'>
                    <span class="span-error" id="span-error-whatsapp">Preencha este campo.</span>
                    
                    <p id="field-ob">*Campo Obrigatório</p>

                    <div class="div-botoes">
                        
                        <button type="button" class="btn" id="btn-toggle" tabindex='16' onclick="toggleForm(2)">
                            Anterior
                        </button>

                        <button type="button" class="btn" id="btn-toggle" tabindex='17' onclick="toggleForm(4)">
                            Próximo
                        </button>
                        
                    </div>                 
                </div>

                <!-- CADASTRO PARTE 4 -->
                <div class="form-cadastro step-4" style="display: none;">

                    <label>Login*</label>
                    <input type="text" class="form-control form-field" id="field-login"  maxlength="100" tabindex='18'>
                    <span class="span-error" id="span-error-login">Preencha este campo.</span>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Senha*</label>
                            <input type="password" class="form-control form-field" id="field-senha"  maxlength="100" tabindex='19'>
                            <span class="span-error" id="span-error-senha">Preencha este campo.</span>
                        </div>
                        <div class="col-md-6">
                            <label>Confirme sua senha*</label>
                            <input type="password" class="form-control form-field" id="field-confSenha" maxlength="100" tabindex='20'>
                            <span class="span-error" id="span-error-confSenha">Preencha este campo.</span>
                        </div>
                    </div>

                    <p id="field-ob">*Campo Obrigatório</p>

                    <div class="div-botoes">
                        <button type="button" class="btn" id="btn-toggle" tabindex='21' onclick="toggleForm(3)">
                            Anterior
                        </button>

                        <button type="button" class="btn" id="btn-finalizar" tabindex='22' onclick="finalizar()">
                        Finalizar 
                        </button>
                    </div>

                </div>
        </div>
    </div>

</div>

<p style="margin-top: 30px;"></p>

<?php require $this->checkTemplate("footer");?>

    <!-- The Modal -->
    <div id="modal-success-register" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <div class="modal-header">
                <p id="modal-title">Cadastro Realizado Com Sucesso!</p>
            </div>
            <div class="modal-body">
                <p id="msg-congrats">Parabéns! Você está um passo mais perto de expandir sua área de ajuda.</p>
                <div class="div-img-modal">
                    <img id="img-modal" src="https://cdn.pixabay.com/photo/2016/08/06/14/11/money-1574450_960_720.png">
                </div>
                <p>Sua conta instituicional foi criada! Mas, para continuar seu cadastro, você deve entrar com seus novos dados em nossa página de login.</p>
                <div class="div-buttons-modal">
                    <hr>
                    <button type="button" class="btn" id="btn-letsgo">Ok, Vamos Lá!</button>
                    <button type="button" class="btn" id="btn-giveup">Farei Isso Depois</button>
                </div>  
            </div>
        </div>
    </div>


</body>

<script src="/BeeBetter/src/backend/ajax.js"></script>
<script src="/BeeBetter/src/cadastro/cadastro.js"></script>

</html>