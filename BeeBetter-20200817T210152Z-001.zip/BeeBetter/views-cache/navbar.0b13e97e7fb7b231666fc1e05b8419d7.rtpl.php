<?php if(!class_exists('Rain\Tpl')){exit;}?>  <!-- Começo da nav-->

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="/BeeBetter/src/navbar/navbar.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->

  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="/BeeBetter/"><img src="/BeeBetter/src/index/imgtcc/logosite.png" style="width:50px;"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <ul class="navbar-nav mr-auto navtexto">
          <li class="nav-item">
            <a class="nav-link" href="/BeeBetter">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/BeeBetter/vitrine">Instituições</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/BeeBetter/sobre">Quem somos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/BeeBetter/faq">Dúvidas</a>
          </li>

        </ul>

        <form class="example" onsubmit="event.preventDefault(); pesquisar();">
          <input type="text" placeholder="Procurar..." name="search"  id="nav-search">
          <button type="submit"><i class="fa fa-search"></i></button>
        </form>

        <button type="button" data-toggle="modal" data-target="#myModal" class="botaoevent" id="btn-acesso">
            <a id="a-acesso" href="/BeeBetter/login" style="text-decoration:none; color:white;">
              Acesso
         </a></button>

      </div>
    </div>
  </nav>

  <script>

    function pesquisar(){

      let query = document.getElementById("nav-search").value;

      sessionStorage.setItem("queryPesquisa", query);
      window.location.href = "/BeeBetter/buscar";
    }

    window.onload = ()=>{

      if(sessionStorage.getItem("id_usuario_logado")){
        
        document.getElementById("a-acesso").innerHTML = "Minha Conta";
        document.getElementById("a-acesso").href = "/BeeBetter/conta";
      };

      let url = window.location.href;

      if(url.match("/BeeBetter/conta")){

        document.getElementById("a-acesso").innerHTML = "Deslogar";
        document.getElementById("a-acesso").href = "#";

        document.getElementById("btn-acesso").addEventListener('click', e=>{

          sessionStorage.removeItem("logado");
          sessionStorage.removeItem("id_usuario_logado");
          sessionStorage.removeItem("reload-imagens");

          window.location.href = "/BeeBetter/login";

        });

      }


    }

  </script>