<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html lang="pt-br">

<head>
  <title>Bee Better</title>
  <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="/BeeBetter/src/index/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="/BeeBetter/src/index/css/all/index.css">
  <link rel="stylesheet" type="text/css" href="/BeeBetter/src/index/css/all/componentes.css">


  <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->
</head>

<body>
  <?php require $this->checkTemplate("navbar");?>
  <!-- CARROSEL CAROUSEL CAROSSINHA -->
  
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100"
            src="/BeeBetter/src/index/imgtcc/banner1.png"
            alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100"
            src="/BeeBetter/src/index/imgtcc/banner2.png"
            alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100"
            src="/BeeBetter/src/index/imgtcc/banner3.png"
            alt="Third slide">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  


  <!-- tudo abaixo do Slider -->
  <div class="titulosinfo animacao">
  <h1>A importância do tema</h1>
  </div>

  <div class="container">
    <div class="row" style="margin-top: 100px;">
      <section class="animacao">
        <div class="card-group">
          <div class="card">
            <img class="card-img-top" src="/BeeBetter/src/index/imgtcc/icones/iconagasalho.png" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title text-center">A campanha do agasalho</h5>
              <p class="card-text">Tradicionalmente realizada entre os meses de maio e junho. Uma importante campanha para ajudar pessoas contra o frio.</p>
              <p class="card-text"><small class="text-muted">Atualizado em 2020</small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="/BeeBetter/src/index/imgtcc/icones/iconbrinquedos.png" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title text-center">A arrecadação de brinquedo</h5>
              <p class="card-text">Geralente comemorado em diversas datas. A importancia desta campanha tem foco em crianças carentes.</p>
              <p class="card-text"><small class="text-muted">Atualizado em 2020</small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="/BeeBetter/src/index/imgtcc/icones/iconalimentos.png" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title text-center">A campanha de alimentos</h5>
              <p class="card-text">Alertar a sociedade sobre a importância de uma alimentação saudável. Dia Mundial da Alimentação, comemorado em 16 de outubro.</p>
              <p class="card-text"><small class="text-muted">Atualizado em 2020</small></p>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
  <!-- fIM DO CONTAINER-->

  <!-- NOVA DIVISÃO -->

 
<div class="container-fluid" style="background: rgba(0,0,0,.05);">
  <div class="container">
    <!-- COMEÇA AQUI -->
    <div class="titulosinfo animacao">
  <h1 class="text-left">Nossa equipe</h1>
  </div>
    <div class="row">
      <div class="col-md-6">
        <div class="img-fluid">
          <img src="/BeeBetter/src/index/imgtcc/grupo.jpg" class="animacao"
            style="width: 100%; height: 50%; margin-top: 25px; margin-bottom: 25px; border-radius: 5px; box-shadow: 10px 10px 5px #aaaaaa;">
        </div>
      </div>
      <div class="col-md-6 animacao">
        <p class="text-left" style="color: blueviolet; font-family: sans-serif; margin-top: 100px;" class="animacao">
          Conheça um pouco sobre o nosso grupo e o que levou escolhermos o tema do nosso site.</p>
        <a href="qs.php"><button class="btnlinks">Quem Somos</button></a>
      </div>
    </div>
  </div>
</div>

  <!--OUTRO ITEM-->
 
 <!-- <div class="container-fluid">
 <div class="titulosinfo animacao">
  <h1>Instituições em destaque</h1>
  </div>
 <div class="destaques animacao"> 
      <ul class="cartas" id="cartas-ul">

        <div class="item">
          <img class="itemdestaque" src="https://atualiza.acicampinas.com.br/ADMblog/thumbs/323..jpg" alt="fundo">
        </div>

      </ul>
    </div>
 </div>
  </div> -->

  
      
 
  
  <div class="container-fluid divfaq" style="background-image: url('/BeeBetter/src/index/imgtcc/banner4.png');">
  <div class="container">
  <div class="titulosinfo animacao">
  <h1 class="text-left">Alguma dúvida ?</h1>
  </div>
  <div class="row">
      <div class="col-md-6 animacao">
        <h1 class="text-left" class="animacao" >
          Nosso site tem uma área só para perguntas frequentes.</h1>
        <a href="faq.php"><button class="btnlinks">Dúvidas sobre o site?</button></a>
      </div>

    </div>
  </div>
  </div>
 

  <!-- footer -->
  <?php require $this->checkTemplate("footer");?>


</body>
<script>
  let isDown = false;
let startX;
let scrollLeft;
const slider = document.querySelector('.cartas');

const end = () => {
    isDown = false;
  slider.classList.remove('active');
}

const start = (e) => {
  isDown = true;
  slider.classList.add('active');
  startX = e.pageX || e.touches[0].pageX - slider.offsetLeft;
  scrollLeft = slider.scrollLeft;	
}

const move = (e) => {
    if(!isDown) return;

  e.preventDefault();
  const x = e.pageX || e.touches[0].pageX - slider.offsetLeft;
  const dist = (x - startX);
  slider.scrollLeft = scrollLeft - dist;
}

(() => {
    slider.addEventListener('mousedown', start);
    slider.addEventListener('touchstart', start);

    slider.addEventListener('mousemove', move);
    slider.addEventListener('touchmove', move);

    slider.addEventListener('mouseleave', end);
    slider.addEventListener('mouseup', end);
    slider.addEventListener('touchend', end);
})();</script>

<!-- jQuery -->

<script type="text/javascript" src="/BeeBetter/src/index/js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="/BeeBetter/src/index/js/animacao.js"></script>
<script type="text/javascript" src="/BeeBetter/src/index/js/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="/BeeBetter/src/index/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="/BeeBetter/src/index/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="/BeeBetter/src/index/js/mdb.min.js"></script>
<!-- Your custom scripts (optional) -->
<script type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script src="/BeeBetter/src/backend/ajax.js"></script>
<script type="text/javascript" src="/BeeBetter/src/index/index.js"></script>

</html>