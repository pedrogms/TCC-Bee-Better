<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<head>

    <title>Error 404</title>
    
    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <style> 

        .bg-error-code{
           background-color: rgb(211, 206, 211);
        }

        #error-code{
            padding: 15px;
            font-size: 80px;
            color: rgb(61, 12, 63);
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            align-items: center;
            justify-content: center;
            display: flex;
        }
        
        #message{
            font-size: 25px;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;  
            text-align: justify;

            margin-top: 25%;            
        }
    </style>
</head>

<body>

    <?php require $this->checkTemplate("navbar");?>
    <p style="margin-top: 30px;"></p>

    <div class="bg-error-code">
        <p id="error-code">Error 404 (Page Not Found)</p>
    </div>

    <div class="container">
        <div class="row">

            <div class="col-md-6">
                <p id="message">Não conseguimos encontrar a página que você está procurando! Verifique se o link de acesso foi digitado 
                    de forma adequada, e tente novamente. </p>

                <p id="message">Nosso amigo Teddy vai esperar você conferir!</p>
            </div>

            <div class="col-md-6">
                <img src="http://www.pngplay.com/wp-content/uploads/2/Teddy-Bear-Transparent-File.png">
            </div>

        </div>
    </div> 

    <p style="margin-top: 30px;"></p>
    <?php require $this->checkTemplate("footer");?>

</body>
</html>