<?php if(!class_exists('Rain\Tpl')){exit;}?><head>
    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/footer/footer.css">

</head>


<!--inicio footer-->
<div class="container-fluid rodape">
    <div class="container">
        <div class="row">
            <div class="col-sm">

                <h1 style="margin-bottom: 30px;">MAPA DO SITE</h1>
                <ul style="text-decoration: none;list-style-type: none; ">
                    <li>
                        <a class="texto-footer" href="/BeeBetter/">Home</a>
                    </li>

                    <li>
                        <a class="texto-footer" href="/BeeBetter/vitrine">Instituições</a>
                    </li>
                    <li>
                        <a class="texto-footer" href="/BeeBetter/sobre">Quem somos</a>
                    </li>

                    <li>
                        <a class="texto-footer" href="/BeeBetter/faq">FAQ</a>
                    </li>

                    <li>
                        <a class="texto-footer" href="/BeeBetter/login">Login/Cadastro</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm">
                <h1 style="margin-bottom: 30px;">SOBRE A BEE BETTER</h1>
                <p class="texto-footer"> Bee Better é um projeto de estudantes do ensino técnico com o intuíto de expandir a divulgação e facilitar o trabalho de
                    instituições de caridade.</p>
            </div>
            <div class="col-sm">
                <h1 style="margin-bottom: 30px;">ENTRE EM CONTATO</h1>
                <i class="fa fa-envelope-square" style="margin-left: 30px; font-size: 20px;"></i>
                <a class="texto-footer" href="mailto:ong@gmail.com">Enviar email para nossa equipe</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid barra">Copyright © 2020. Todos os direitos reservado 7ETEC TEAM</div>

<!-- <div class="container-fluid barra">
        <p>@Copyright 2020 7ETEC. Todos os direitos reservados.</p>
    </div> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">