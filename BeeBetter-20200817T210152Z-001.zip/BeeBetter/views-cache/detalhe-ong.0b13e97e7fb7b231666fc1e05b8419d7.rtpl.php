<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html>

<head>
    <link rel="shortcut icon" href="/BeeBetter/src/index/imgtcc/logosite.png" type="image/x-icon" />
    <title id="title-page">Sem informações</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- <link rel="stylesheet" type="text/css" href="../../components/navbar/css/navbar.css"> -->
    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/detalhe/detalhe-ong.css">
    
</head>
<body>

    <?php require $this->checkTemplate("navbar");?>
    <p style="padding:30px"></p>

    <div class="container">

        <div class="row main-page">

            <!-- ESQUERDA DA PÁGINA -->
            <div class="col-7 page-left"> 

                <!---------- INFROMAÇÕES INICIAIS ---------->
                <div class="row info-all m-0">

                    <div class="info-header">
                        <p id="inst-name">Sem informações</p>

                        <div class="d-flex justify-content-between">
                            <div class="info-tag" title="Causa Social" id="info-causa-social">Sem informações</div>
                            <span id="info-cidade-uf"> Sem informações</span>
                        </div>
                    </div>

                    
                    <div class="info-content">
                        <hr>
                        <span class="page-mini-title">Descrição</span>
                        <p id="description-text">As Organizações não Governamentais (ONGs) são organizações sem fins lucrativos, constituídas formalmente e autonomamente, caracterizadas por ações de solidariedade no campo das políticas públicas e pelo legítimo exercício de pressões políticas em proveito de populações excluídas das condições da cidadania.[1] Sua ascensão histórica está ligada à crise fiscal do Estado e ao desenvolvimento da sociedade civil no sentido de uma cidadania ativa. Porém, seu conceito não é pacífico na doutrina, existindo muitas divergências. Fazem parte do chamado setor terciário, o setor de serviços e comércio. No entanto, algumas teses o definem como parte do setor quinário, o setor sem fins lucrativos.</p>   
                    </div>

                </div>

                <!---------- POSTAGENS INSTITUIÇÃO ---------->
                <div class="row inst-posts m-0">
                    <hr>
                    <span class="page-mini-title">Postagens <img class="explanation-icon" title="As postagens são comunicados, eventos, novidades, entre outras atividades divulgadas pela instituição. Clique em uma postagem para ampliar" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Finformation.svg?alt=media&token=bb5edb71-c7de-4c6a-a3b1-f0bb20a17572"></span>
                    
                    <div id="linha-postagens"></div>
                    <!-- Modelo Postagem
                    <div class="row post-preview">
                        <div class="col-10">
                            <p class="post-prev-title post-prev-color">Fim da linha para aqueles que têm fome </p>
                            <p class="post-prev-text">Algum texto da postagem, que será mostrado apenas em seus caracteres iniciais no post-preview.</p>
                        </div>

                        <div class="col-2 post-prev-date ">
                            <span class="post-prev-color">25/05</span>
                        </div>
                    </div> -->

                      

                </div>

            </div>
                

            <!-- DIREITA DA PÁGINA -->
            <div class="col-5 mt-3 pr-0">
                
                <!-------- IMAGENS ------->
                <div class="card-wrap">
                    <!-- Principal -->
                    <div class="images-container">
                        <img id="main-image" src="https://homestaymatch.com/images/no-image-available.png">
                    </div>

                    <!-- Miniaturas -->
                    <div class="miniatures-container" id="linha-miniaturas">
                        
                        <!-- <div class="mini-box">  
                            <img src="https://homestaymatch.com/images/no-image-available.png">
                        </div> -->

                    </div>
                </div>

                <!-------- COMO AJUDAR ------->
                <div class="card-wrap">
                    <p class="card-wrap-title">Como posso ajudar?</p>
                    <hr>
                    
                    <p>Entre em contato com a Instituição através de uma das informações abaixo.</p>
                    <!-- Adicionar classe .has-info na tag <a/> para display = block do ícone  -->

                    <div class="regular-media">

                        <div class="item-line">
                            <span><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Faddress.svg?alt=media&token=c7b4637a-59c3-4a76-8dbd-548c5fc8237b"> <span class="data-text" id="media-endereco">Sem informações</span></span>
                        </div>

                        <div class="item-line">
                            <span><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Fmail.svg?alt=media&token=0d4b5a3b-3992-47fb-b854-314838ef5caf"> <span class="data-text" id="media-email">Sem informações</span></span>
                        </div>

                        <div class="item-line">
                            <span><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Fphone.svg?alt=media&token=d63acc19-809d-42bf-ad2e-7472053fbf75"><span class="data-text" id="media-phone">Sem informações</span></span>
                        </div>

                        <div class="item-line">
                            <span><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Fwhatsapp.svg?alt=media&token=c5a565bd-51db-477d-9ac6-822c35f8ad08"><span class="data-text" id="media-whatsapp">Sem informações</span></span>

                            <span><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Fwhatsapp.svg?alt=media&token=c5a565bd-51db-477d-9ac6-822c35f8ad08"><span class="data-text" id="media-whatsapp-two">Sem informações</span></span>
                        </div>

                    </div>

                    <div class="social-media">
                        <!-- Facebook -->
                        <a href="#" class="a-displayer-none" id="media-facebook" target="_blank"><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Ffacebook.svg?alt=media&token=978b55c1-d10d-46b6-b992-3cf7da05ae4e"></a>
                        <!-- Twitter -->
                        <a href="#" class="a-displayer-none" id="media-twitter" target="_blank"><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Ftwitter.svg?alt=media&token=2304fc5c-06e7-4069-9b5c-6877d79d52f4"></a>
                        <!-- Instagram -->
                        <a href="#" class="a-displayer-none" id="media-instagram" target="_blank"><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Finstagram.svg?alt=media&token=9fe9ccb6-6d11-4910-af25-e96e990b5a8d"></a>
                        <!-- Youtube -->
                        <a href="#" class="a-displayer-none" id="media-youtube" target="_blank"><img class="table-media-icon" src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fsocial_media_icons%2Fyoutube.svg?alt=media&token=1ef7ab90-286e-42cf-a36e-fa21763a501e"></a>

                    </div>

                </div>
                
            </div>
        </div>

        <!------- PROPAGANDA ONGS SIMILARES ------->
        <div class="advertisement-inst">
            <p class="page-subtitle">Veja outras instituições que precisam de ajuda</p>
            <!------------ Instituições em Destaque ------------->

            <div class="d-flex flex-column">
                <div class="row row-height-control" id="row-cards">

                    <!-- Modelo Padrão para Card Destaque -->
                    <!-- <div class="destaque-card">
                        <div class="destaque-img">
                            <img src="https://img.itdg.com.br/tdg/images/blog/uploads/2019/05/deixar-o-sorvete-caseiro-mais-cremoso.jpg">
                        </div>
                        <hr>
                        <div class="card-text destaque-nome-inst">Nome da instituição</div>
                        <div class="card-text destaque-local-inst">Unidade Federativa</div>
                        <div class="card-text destaque-causa-inst" title="Causa Social">Arrecadação de Alimentos</div>
                    </div> -->


                </div>
            </div>
        </div>

          <!------- MODAL POSTAGENS ------->
        <div id="myModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
                <div class="post-header">
                    <span id="post-name">Nome da Instituição</span>           
                    <span class="close">&times;</span>
                </div>

                <div class="post-content">
                    <p id="post-title">Fim da linha para aqueles que tem fome</p>
                    <div id="post-text">
                        As Organizações não Governamentais (ONGs) são organizações sem fins lucrativos, constituídas formalmente e autonomamente, caracterizadas por ações de solidariedade no campo das políticas públicas e pelo legítimo exercício de pressões políticas em proveito de populações excluídas das condições da cidadania.[1] Sua ascensão histórica está ligada à crise fiscal do Estado e ao desenvolvimento da sociedade civil no sentido de uma cidadania ativa. Porém, seu conceito não é pacífico na doutrina, existindo muitas divergências. Fazem parte do chamado setor terciário, o setor de serviços e comércio. No entanto, algumas teses o definem como parte do setor quinário, o setor sem fins lucrativos.    
                    </div>
                </div>
                
                <div class="post-comments">
                    <span class="com-title">Comentários</span>
                    <div class="append-comment" id="append-comment">

                        <!-- Modelo para comentário
                        <div class="comment-block">
                            <div class="com-top">
                                <span id="com-author">Pedro Henrique Ferreti de Souza</span>
                                <span id="com-date-time">28/05/2020 18:40</span>
                            </div>
                            <div id="com-text">
                                Adorei sua ong. Vou ajudar!
                            </div>
                        </div> -->

                    </div>
                    <div class="send-comment">
                        
                        <label>Nome*</label>
                        <input type="text" class="form-control form-field" placeholder="Nome Completo" id="field-nome-comentario">
                        <span class="span-error">Preencha este campo.</span>
                        <label>Email*</label>
                        <input type="text" class="form-control form-field" placeholder="Email" id="field-email-comentario">
                        <span class="span-error">Preencha este campo.</span>
                        <label>Comentário*</label>
                        <textarea class="form-control form-field" id="field-comentario" rows="5"></textarea>
                        <span class="span-error">Preencha este campo.</span>

                        <button class="btn btn-send-comment" onclick="enviarComentario()">Enviar Comentário</button>
                    </div>
                    

                </div>

            </div>

        </div>


    </div>

    <p style="padding:30px"></p>
    <?php require $this->checkTemplate("footer");?>

    <script src="/BeeBetter/src/backend/ajax.js"></script>
    <script src="/BeeBetter/src/detalhe/detalhe-ong.js"></script>
</body>
</html>