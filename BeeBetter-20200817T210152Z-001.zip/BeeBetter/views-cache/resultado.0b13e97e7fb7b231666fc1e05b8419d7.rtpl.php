<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- <link rel="stylesheet" type="text/css" href="../../components/navbar/css/navbar.css"> -->
    <link rel="stylesheet" type="text/css" href="/BeeBetter/src/buscar/resultado.css">
    <title>Buscar | BeeBetter</title>
</head>
<body>

    <?php require $this->checkTemplate("navbar");?>
    <p style="margin-top: 30px;"></p>

    <div class="container">

        <div class="row">

            <!-- ------------ FILTROS DE PESQUISA------------ -->
            <aside class="col-3 result-filter">
                <div class="row">
                    <p class="filter-query" id="query"></p>
                </div>
                <div class="row filter-results-found" id="total-resultados"></div>
                
                <!-- Filtros Ativados -->
                <!-- <div class="row">
                    <ul class="filter-active-ul">
                        <li title="Remover filtro">São Paulo <span aria-hidden="true">&times;</span></li>
                    </ul>
                </div> -->
                
                <hr>
                <div class="row filter-word-filter">Filtrar por:</div>

                <p class="filter-type-title">Localização</p>
                <div class="row filter-param">
                    <select class="filter-select" id="filter-select-localizacao" onchange="filtroLocalizacao(this.value)">
                        <option class="filter-select-option">Todas</option>
                        <option class="filter-select-option">Acre</option>
                        <option class="filter-select-option">Alagoas</option>
                        <option class="filter-select-option">Amapá</option>
                        <option class="filter-select-option">Amazonas</option>
                        <option class="filter-select-option">Bahia</option>
                        <option class="filter-select-option">Ceará</option>
                        <option class="filter-select-option">Distrito Federal</option>
                        <option class="filter-select-option">Espírito Santo</option>
                        <option class="filter-select-option">Goiás</option>
                        <option class="filter-select-option">Maranhão</option>
                        <option class="filter-select-option">Mato Grosso</option>
                        <option class="filter-select-option">Minas Gerais</option>
                        <option class="filter-select-option">Pará</option>
                        <option class="filter-select-option">Paraíba</option>
                        <option class="filter-select-option">Paraná</option>
                        <option class="filter-select-option">Pernambuco</option>
                        <option class="filter-select-option">Piauí</option>
                        <option class="filter-select-option">Rio de Janeiro</option>
                        <option class="filter-select-option">Rio Grande do Norte</option>
                        <option class="filter-select-option">Rio Grande do Sul</option>
                        <option class="filter-select-option">Rondônia</option>
                        <option class="filter-select-option">Roraima</option>
                        <option class="filter-select-option">Santa Catarina</option>
                        <option class="filter-select-option">São Paulo</option>
                        <option class="filter-select-option">Sergipe</option>
                        <option class="filter-select-option">Tocantins</option>
                    </select>
                </div>

                <p class="filter-type-title">Causa Social</p>
                <div class="row filter-param">
                    <select class="filter-select" id="filter-select-causa-social" onchange="filtroCausaSocial(this.value)">
                        <option class="filter-select-option">Todas</option>
                        <option class="filter-select-option">Assistência Educacional</option>
                        <option class="filter-select-option">Assistência Financeira</option>
                        <option class="filter-select-option">Assistêcia Médica</option>
                        <option class="filter-select-option">Auxílio a Moradores de Rua</option>
                        <option class="filter-select-option">Doação de Roupas</option>
                        <option class="filter-select-option">Doação de Alimentos</option>
                        <option class="filter-select-option">Proteção Ambiental</option>
                    </select>
                </div>
                    
            </aside>

            <!-- ------------ DISPLAYER DOS RESULTADOS DE PESQUISA ------------ -->
            <div class="col-9 result-display">

                <!-- ----------- Modelo Padrão para Exbir Ong como Resulatdo de Pesquisa  -------------
                <div class="row result-card-inst">
                    <div class="col-4 result-card-photo">
                        <img src="https://http2.mlstatic.com/D_NQ_NP_847299-MLA40692342173_022020-O.webp">

                    </div>
                    <div class="col-8">
                        <div class="row">
                            <p class="result-card-title">Organização Exemplo</p>
                        </div>
                        <div class="row result-card-desc">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer interdum dapibus leo, quis tempor velit porttitor in. Ut enim felis, pretium quis nulla sit amet, dapibus varius elit. Nam nulla lorem, lacinia ut lacus sit amet, convallis porta enim. Pellentesque sit amet facilisis nisl, non molestie leo. Integer imperdiet nisi.
                        </div>
                        <div class="row result-card-tags">
                            <ul class="d-flex justify-content-around result-card-ul">
                                <li title="Pesquisar por causa social">Assistêcia Financeira</li>
                                <li title="Pesquisar por causa social">Doação de Móveis</li>
                                <li title="Pesquisar por causa social">Assistência Educacional</li>
                            </ul>
                        </div>
                    </div>
                </div> -->

                <div class="no-result" id="no-result">
                    Nenhum resultado encontrado.
                </div>

                <div id="resultadosPesquisa"></div>

            </div>

        </div>
    </div>

    <p style="margin-top: 30px;"></p>
    <?php require $this->checkTemplate("footer");?>

</body>
    <script src="/BeeBetter/src/backend/ajax.js"></script>
    <script src="/BeeBetter/src/buscar/resultado.js"></script>
</html>