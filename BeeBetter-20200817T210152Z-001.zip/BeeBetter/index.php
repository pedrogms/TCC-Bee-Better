<?php

require_once("vendor/autoload.php");

use Rain\Tpl;
use \Slim\Slim;

$app = new Slim();

$config = array(
    "tpl_dir"     => $_SERVER["DOCUMENT_ROOT"] . "/BeeBetter" . "/views/",  
    "cache_dir"   => $_SERVER["DOCUMENT_ROOT"] . "/BeeBetter" . "/views-cache/", 
    "debug"       => false // set to false to improve the speed
);

Tpl::configure($config);

$app->get('/', function(){

    $tpl = new Tpl();

    $tpl->draw('index');

});

$app->get('/cadastro', function(){

    $tpl = new Tpl();

    $tpl->draw('cadastro');

});

$app->get('/login', function(){

    $tpl = new Tpl();

    $tpl->draw('login');

});

$app->get('/conta', function(){

    $tpl = new Tpl();

    $tpl->draw('conta');

});

$app->get('/vitrine', function(){

    $tpl = new Tpl();

    $tpl->draw('vitrine');

});

$app->get('/detalhes', function(){

    $tpl = new Tpl();

    $tpl->draw('detalhe-ong');

});

$app->get('/buscar', function(){

    $tpl = new Tpl();

    $tpl->draw('resultado');

});

$app->notFound(function(){

    $tpl = new Tpl();
    $tpl->draw('error404');

});

$app->run();


?>