$(document).ready(function() {

   if(verificarLogin() === true){
       toggleConfigOption(0);
       carregarDados();
       carregaTodosEventosParaBotões();
        iniciarFirebase();

      if(sessionStorage.getItem("reload-imagens")){ // Caso seja um reload da página após upload.
           toggleConfigOption(2); 
             sessionStorage.removeItem("reload-imagens");
        }

    }

});

function carregarDados(){

    let dados = {id: sessionStorage.getItem("id_usuario_logado").toString()};
    var call = connectionAjax(dados, "4");

    var campos = [
        {id: "profile-razao-social", valor: "razao_social"},
        {id: "profile-cnpj", valor: "cnpj"},
        {id: "profile-causa-social", valor: "causa_social"},
        {id: "profile-descricao", valor: "descricao"},
        {id: "profile-cep", valor: "cep"},
        {id: "profile-rua", valor: "rua"},
        {id: "profile-numero", valor: "numero_residencial"},
        {id: "profile-bairro", valor: "bairro"},
        {id: "profile-cidade", valor: "cidade"},
        {id: "profile-uf", valor: "uf"},
        {id: "profile-fone-fixo", valor: "telefone_fixo"},
        {id: "profile-whatsapp1", valor: "whatsapp1"},
        {id: "profile-whatsapp2", valor: "whatsapp2"},
        {id: "profile-facebook", valor: "facebook"},
        {id: "profile-instagram", valor: "instagram"},
        {id: "profile-youtube", valor: "youtube"},
        {id: "profile-twitter", valor: "twitter"},
        {id: "profile-email", valor: "email"},
        //{id: "profile-senha", valor: "value_senha"},
    ];
    

    campos.map((campo) =>{
        return document.getElementById(campo.id).value = call.userData[campo.valor];
    });

    /*var*/ senha_usuario = call.userData.value_senha;

    writeUF(call.userData.uf);

    document.getElementById("titulo").innerHTML = call.userData.razao_social.toString();
    
    carregarImagens(call.userData.imagens);
    carregarPostagens(call.userData.posts);

    if(call.userData.ativo.toString() === "0"){
        document.getElementById("status-conta").innerHTML = "Sua Conta está Desativada!";
        document.getElementById("status-conta").style.color = "red";

    }
    
}

function carregarImagens(data){

    arrayImgs = []; /* Variável global*/
    arrayImgs = data;

    document.getElementById("acc-photo").src = arrayImgs[0].imagem;
    document.getElementById("img-preview").src = arrayImgs[0].imagem;

    for(i=1; i < arrayImgs.length; i++){
        document.getElementById(`send-image-${i-1}`).src = arrayImgs[i].imagem;
    }

    verificaImagensPreenchidas();

}

function carregarPostagens(posts){

    postagens = posts;
    posts = posts.reverse();

    if(posts[0].id_post){
        posts.map((post)=>{

            let postagem = `
                <div class="post-init">
                    <div class="post-spoiler">
                        <p class="spoiler-title" id="post-${post.id_post.toString()}">${post.titulo}</p>
                        <p class="spoiler-text">${post.postagem.substring(0, 30)}...</p>
                    </div>
                    <p class="spoiler-post-data">${formatarData(post.dta_post)}</p>
                    <p><span id="spoiler-commentary-number">${post.comments.length}</span> comentários</p>
                    <p class="post-delete-icon" title="Excluir Postagem"><img src="https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fnew-delete.svg?alt=media&token=f8819141-dbb2-4081-8753-585bf8faedc2"></p>
                </div>
            `;

            $("#div-post-main").append(postagem);
        });
    }
}

function iniciarFirebase(){

    var firebaseConfig = {
        apiKey: "AIzaSyBL7hzHdRWks72IQ8zkHeNxagvjbiw4-Ow",
        authDomain: "beebetter-394f3.firebaseapp.com",
        databaseURL: "https://beebetter-394f3.firebaseio.com",
        projectId: "beebetter-394f3",
        storageBucket: "beebetter-394f3.appspot.com",
        messagingSenderId: "552675943558",
        appId: "1:552675943558:web:d385ffa7882c01b58f1d07"
    };

    var firebaseConfig2 = {
        apiKey: "AIzaSyD3AakwGhG34hz2j6dBRh_cw4c4zl6Y0hE",
        authDomain: "beebetter-fdf09.firebaseapp.com",
        databaseURL: "https://beebetter-fdf09.firebaseio.com",
        projectId: "beebetter-fdf09",
        storageBucket: "beebetter-fdf09.appspot.com",
        messagingSenderId: "412782222044",
        appId: "1:412782222044:web:f3d2d605cc091df1e3f219"
      };
    
    firebase.initializeApp(firebaseConfig2);

}

async function uploadImagemGaleria(){

    let file = document.getElementById("send-input-upload").files[0];

    switch(file.type){

        case 'image/jpeg':
        case 'image/jpg':
        case 'image/png':

            let imgId = makeid(file.name.length); // Cria um id aleatório, uma vez que o Firebase substitui imagens como nomes iguais.
            
            const upload = firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${imgId}`).put(file);

            await upload.on('state_changed',
                (snapshot)=>{
                    console.log("progresso");
                }, 
                (erro)=>{
                    console.log(erro);   
                }, 
                ()=>{

                    firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${imgId}`).getDownloadURL().then(url =>{

                        let dados = {
                            url: encodeURIComponent(url),
                            nome_imagem: imgId,
                            id_ong: sessionStorage.getItem("id_usuario_logado").toString()
                        }

                        console.log(dados);

                        let call = connectionAjax(dados, "11");

                        if(call.error === false){
                            alert("Upload realizado com sucesso!");
                            sessionStorage.setItem("reload-imagens", true);
                            location.reload();
                        }
                    });
                }
            );
            
        break;

        default:
            alert('Formato de arquivo inválido');
    }

}

async function deletarImagem(){
    let imgUrl = document.getElementsByClassName("send-selected-photo")[0].src;

    arrayImgs.map((imagens)=>{

        if(imagens.imagem === imgUrl){

            firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${imagens.nome_imagem}`).delete().then(()=>{

                let dados = {
                    id_imagem: imagens.id_imagem,
                    url: encodeURIComponent(imgUrl)
                };
                let call = connectionAjax(dados, "12");

                if(call.error === false){
                    alert(" Imagem deletada com sucesso!");
                    sessionStorage.setItem("reload-imagens", true);
                    location.reload();
                }

            }).catch((error)=>{
                alert(error);
            });
        }
    });

}

function imgPreview(){

    let img = document.getElementById("img-preview");

    let file = document.getElementById("input-file").files[0];

    let fileReader = new FileReader();

    fileReader.onload = () =>{
        img.src = fileReader.result;
        img.style.display = "block";
    }

    switch(file.type){

        case 'image/jpeg':
        case 'image/jpg':
        case 'image/png':
            fileReader.readAsDataURL(document.getElementById("input-file").files[0]);
        break;

        default:
            alert('Formato de arquivo inválido');
    }

   
}

async function alterarFotoPerfil(){
    
    let file = document.getElementById("input-file").files[0];

    switch(file.type){

        case 'image/jpeg':
        case 'image/jpg':
        case 'image/png':

            // Remove a imagem de perfil atual
            if(arrayImgs[0].nome_imagem !== "padrao"){
                firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${arrayImgs[0].nome_imagem}`).delete().then(()=>{
                }).catch((error)=>{
                    console.log(error);
                    alert("Erro ao deletar imagem!");
                });    
            }
            
            let imgId = makeid(file.name.length); // Cria um id aleatório, uma vez que o Firebase substitui imagens como nomes iguais.
            
            const upload = firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${imgId}`).put(file);

            await upload.on('state_changed',
                (snapshot)=>{
                    console.log("progresso");
                }, 
                (erro)=>{
                    console.log(erro);   
                }, 
                ()=>{

                    firebase.storage().ref(`imagensUsuarios/${sessionStorage.getItem("id_usuario_logado")}/${imgId}`).getDownloadURL().then(url =>{

                        arrayImgs[0].imagem = url;
                        arrayImgs[0].nome_imagem = imgId;

                        let dados = {
                            id_imagem: arrayImgs[0].id_imagem,
                            url: encodeURIComponent(url),
                            nome_imagem: imgId
                        }

                        console.log(dados);

                        let call = connectionAjax(dados, "10");

                        if(call.error === false){
                            alert("Upload realizado com sucesso!");
                            window.location.reload();
                        }
                    });
                }
            );
            
        break;

        default:
            alert('Formato de arquivo inválido');
    }

    

}

function salvarAlteracoesPerfil(){

    if(document.getElementById("config-main-edit-data").innerHTML === "Salvar Dados"){

        let dados = {
            id: sessionStorage.getItem("id_usuario_logado").toString(),
            razao_social: document.getElementById("profile-razao-social").value.toString().trim(),
            email: document.getElementById("profile-email").value.toString().trim(),
            cnpj: document.getElementById("profile-cnpj").value.toString().trim(),
            causa_social:  document.getElementById("profile-causa-social").value.toString().trim(), 
            descricao:  document.getElementById("profile-descricao").value.toString().trim().replace(/[']/g, ""), 
            cep: document.getElementById("profile-cep").value.toString().trim(),
            rua: document.getElementById("profile-rua").value.toString().trim(), 
            numero_residencial: document.getElementById("profile-numero").value.toString().trim(),
            bairro: document.getElementById("profile-bairro").value.toString().trim(),
            cidade: document.getElementById("profile-cidade").value.toString().trim(),
            uf: document.getElementById("profile-uf").value.toString().trim(),
            telefone_fixo: document.getElementById("profile-fone-fixo").value.toString().trim().replace(/[^0-9]/g, ""),
            whatsapp1: document.getElementById("profile-whatsapp1").value.toString().trim().replace(/[^0-9]/g, ""),
            whatsapp2: document.getElementById("profile-whatsapp2").value.toString().trim().replace(/[^0-9]/g, ""),
            facebook: encodeURIComponent(document.getElementById("profile-facebook").value.toString().trim()),
            instagram: encodeURIComponent(document.getElementById("profile-instagram").value.toString().trim()),
            twitter: encodeURIComponent(document.getElementById("profile-twitter").value.toString().trim()),
            youtube: encodeURIComponent(document.getElementById("profile-youtube").value.toString().trim())
        }

        console.log(dados);

        if(validarDados(dados)){

            let call = connectionAjax(dados, "2");

            if(call.error === false){

                alert("Salvo com sucesso!");
                window.location.reload();

            } else{
                console.log("Erro na Alteração");
            }
        }
        
    }
}

function validarDados(data){

    let retorno = true;

    // Verifica campos vazios
    Object.keys(data).map((campo)=>{ 

        if (data[campo] === ""){

            if(campo !== "cnpj" && campo !== "descricao" && campo !== "telefone_fixo" && campo !== "whatsapp1" && campo !== "whatsapp2" && campo !== "facebook" && campo !== "instagram" && campo !== "youtube" && campo !== "twitter"){
                console.log(campo);
                toggleErrorDesign(`profile-${campo}`, `span-error-profile-${campo}`);
                retorno = false;
            }

        }
    });

    if (data.cnpj !== ""){

        if(validarCNPJ(data.cnpj) === false){
            toggleErrorDesign("profile-cnpj", "span-error-profile-cnpj", "O CNPJ informado é inválido.");   
            retorno = false;
        }

        if(validarCNPJ(data.cnpj) === true){
            if(verificarCNPJ(data.cnpj) === true){
                toggleErrorDesign("profile-cnpj", "span-error-profile-cnpj", "O CNPJ informado já está cadastrado.");   
                retorno = false;
            }  
        }  
    }

    if(data.email !== ""){
        if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(data.email) === false){
            toggleErrorDesign("profile-email", "span-error-profile-email", "O E-mail informado é inválido.");   
            retorno = false;
        }

        if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(data.email) === true){

            if(verificarEmail(data.email) === true){
                toggleErrorDesign("profile-email", "span-error-profile-email", "O E-mail informado já está cadastrado.");   
                retorno = false;
            }
        }
    }

    return retorno;
}

function inserirPostagem(){

    let titulo = document.getElementById("post-titulo").value.toString().trim().replace(/[']/g, "");
    let conteudo = document.getElementById("post-conteudo").value.toString().trim().replace(/[']/g, "");

    let controle = true;

    if(titulo === ""){
        toggleErrorDesign("post-titulo", "span-error-post-titulo");
        controle = false;
    }

    if(conteudo === ""){
        toggleErrorDesign("post-conteudo", "span-error-post-conteudo");
        controle = false;
    }

    if(controle === true){

        let dados = {
            id_ong: sessionStorage.getItem("id_usuario_logado"),
            titulo: titulo,
            conteudo: conteudo
        }

        let call = connectionAjax(dados, "14");
        if(call.error === false){
            alert("Postagem realizada com sucesso!");
            window.location.reload();
        }
    }
}

function salvarAlteracaoSenha(){
    let senhaAtual = document.getElementById("profile-senha-atual").value;
    let novaSenha = document.getElementById("profile-nova-senha").value;
    let confNovaSenha = document.getElementById("profile-conf-nova-senha").value;

    let controle = true;

    if(novaSenha.length < 5){
        toggleErrorDesign('profile-nova-senha', 'span-error-nova-senha', 'A senha deve ser conter mais de 5 caracteres.');
        controle = false;
    }

    if(confNovaSenha.length < 5){
        toggleErrorDesign('profile-conf-nova-senha', 'span-error-conf-nova-senha', 'A senha deve ser conter mais de 5 caracteres.');
        controle = false;
    }

    if(senhaAtual === ""){
        toggleErrorDesign('profile-senha-atual', 'span-error-senha-atual');
        controle = false;
    }

    if(novaSenha === ""){
        toggleErrorDesign('profile-nova-senha', 'span-error-nova-senha');
        controle = false;
    }

    if(confNovaSenha === ""){
        toggleErrorDesign('profile-conf-nova-senha', 'span-error-conf-nova-senha');
        controle = false;
    }

    if(novaSenha !== confNovaSenha){
        toggleErrorDesign('profile-nova-senha', 'span-error-nova-senha', "As senhas devem ser iguais.");
        toggleErrorDesign('profile-conf-nova-senha', 'span-error-conf-nova-senha', 'As senhas devem ser iguais.');
        controle = false;
    }   

    if(controle === true){

        if(senha_usuario !== senhaAtual){
            toggleErrorDesign('profile-senha-atual', 'span-error-senha-atual', 'Senha incorreta.');

        } else{

            let dados = {id: sessionStorage.getItem("id_usuario_logado").toString(), senha: novaSenha};
            let call = connectionAjax(dados, "2");

            if (call.error === false){
                alert("Senha alterada com sucesso!");
                window.location.reload();
            }
        }
    }
}

function desativarCadastro(){

    let senha = document.getElementById("profile-senha-desativar").value;
    let confSenha = document.getElementById("profile-conf-senha-desativar").value;
    let controle = true;

    if(senha !== confSenha){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar', 'As senhas devem ser iguais.');
        toggleErrorDesign('profile-conf-senha-desativar', 'span-error-profile-conf-senha-desativar', 'As senhas devem ser iguais.');
        controle = false;
    }

    if(senha !== senha_usuario){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar', 'Senha incorreta.');
        controle = false;
    }

    if(senha === ""){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar');
        controle = false;
    }

    if(confSenha === ""){
        toggleErrorDesign('profile-conf-senha-desativar', 'span-error-profile-conf-senha-desativar');
        controle = false;
    }

    if(controle == true){

        let dados = {
            id: sessionStorage.getItem("id_usuario_logado").toString(),
            ativo: "0"
        }
    
        let call = connectionAjax(dados, "3");

        if(call.error === false){
            alert("Desativação realizada com sucesso!");
            window.location.reload();
        }
    }

}

function reativarCadastro(){
    let senha = document.getElementById("profile-senha-desativar").value;
    let confSenha = document.getElementById("profile-conf-senha-desativar").value;
    let controle = true;

    if(senha !== confSenha){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar', 'As senhas devem ser iguais.');
        toggleErrorDesign('profile-conf-senha-desativar', 'span-error-profile-conf-senha-desativar', 'As senhas devem ser iguais.');
        controle = false;
    }

    if(senha !== senha_usuario){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar', 'Senha incorreta.');
        controle = false;
    }

    if(senha === ""){
        toggleErrorDesign('profile-senha-desativar', 'span-error-profile-senha-desativar');
        controle = false;
    }

    if(confSenha === ""){
        toggleErrorDesign('profile-conf-senha-desativar', 'span-error-profile-conf-senha-desativar');
        controle = false;
    }

    if(controle == true){

        let dados = {
            id: sessionStorage.getItem("id_usuario_logado").toString(),
            ativo: "1"
        }
    
        let call = connectionAjax(dados, "3");

        if(call.error === false){
            alert("Reativação realizada com sucesso!");
            window.location.reload();
        }
    }
}

function verificarLogin(){
    if(sessionStorage.getItem("logado") != "true"){
        window.location.href = "/BeeBetter/login";
    } else{
        return true;
    }
}

function verificarCNPJ(cnpj){
    let dados = {cnpj: cnpj}
    let call = connectionAjax(dados, "7");

    if(call.id_ong.toString() === sessionStorage.getItem("id_usuario_logado").toString()){
        call.result = false;
    }

    return call.result;
}

function verificarEmail(email){
    let dados = {email: email}
    let call = connectionAjax(dados, "8");

    if(call.id_ong.toString() === sessionStorage.getItem("id_usuario_logado").toString()){
        call.result = false;
    }

    return call.result;
}

// Método para realizar comunicação com o backend
function connectionAjax(dados, modo = "404"){
    try{    
        let res = ajax(dados, modo);    

        // console.log("Retorno ajax:");
        // console.log(JSON.parse(res));
        return JSON.parse(res);
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}

// Gerar id aleatório
function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

// Método para exibir dados da postagem
function exibirDadosPostagem(postagem){
    
    postagens.map((post)=>{
        if(post.id_post.toString() === postagem.toString().replace(/[^0-9]/g, "")){

            document.getElementById("detail-post-title").innerHTML = post.titulo;
            document.getElementById("detail-post-text").innerHTML = post.postagem;

            post.comments.map((comentario)=>{

                let comment = `
                    <div class="comment-block">
                        <div class="com-top">
                            <span id="com-author">${comentario.nome} - ${comentario.email}</span>
                            <span id="com-date-time">${formatarData(comentario.dta_comentario)}</span>
                        </div>
                        <div id="com-text">
                            ${comentario.comentario.replace(/[\n]/g, "<br>")}
                        </div>
                    </div>
                `;

                $("#append-commentary").append(comment);
            });
        }
    });
}

function validarCNPJ(cnpj) {
 
    cnpj = cnpj.replace(/[^\d]+/g,'');
 
    if(cnpj == '') return false;
     
    if (cnpj.length != 14)
        return false;
 
    // Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" || 
        cnpj == "11111111111111" || 
        cnpj == "22222222222222" || 
        cnpj == "33333333333333" || 
        cnpj == "44444444444444" || 
        cnpj == "55555555555555" || 
        cnpj == "66666666666666" || 
        cnpj == "77777777777777" || 
        cnpj == "88888888888888" || 
        cnpj == "99999999999999")
        return false;
         
    // Valida DVs
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0,tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;
         
    tamanho = tamanho + 1;
    numeros = cnpj.substring(0,tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11
    ;
    if (resultado != digitos.charAt(1)) 
          return false;
           
    return true;
    
}

function writeUF(uf){
    let est = document.getElementById("profile-estado");
    if(uf ==="AC") est.value = "Acre";
    if(uf ==="AL") est.value = "Alagoas";
    if(uf ==="AP") est.value = "Amapá";
    if(uf ==="AM") est.value = "Amazonas";
    if(uf ==="BA") est.value = "Bahia";
    if(uf ==="CE") est.value = "Ceará";
    if(uf ==="DF") est.value = "Distrito Federal";
    if(uf ==="ES") est.value = "Espírito Santo";
    if(uf ==="GO") est.value = "Goiás";
    if(uf ==="MA") est.value = "Maranhão";
    if(uf ==="MT") est.value = "Mato Grosso";
    if(uf ==="MS") est.value = "Mato Grosso do Sul";
    if(uf ==="MG") est.value = "Minas Gerais";
    if(uf ==="PA") est.value = "Pará";
    if(uf ==="PB") est.value = "Paraíba";
    if(uf ==="PR") est.value = "Paraná";
    if(uf ==="PE") est.value = "Pernambuco";
    if(uf ==="PI") est.value = "Piauí";
    if(uf ==="RJ") est.value = "Rio de Janeiro";
    if(uf ==="RN") est.value = "Rio Grande do Norte";
    if(uf ==="RS") est.value = "Rio Grande do Sul";
    if(uf ==="RO") est.value = "Rondônia";
    if(uf ==="RR") est.value = "Roraima";
    if(uf ==="SC") est.value = "Santa Catarina";
    if(uf ==="SP") est.value = "São Paulo";
    if(uf ==="SE") est.value = "Sergipe";
    if(uf ==="TO") est.value = "Tocantins";
}

function isNumberKey(evt) {
    
    var charCode = (evt.which) ? evt.which : event.keyCode

    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

    return true;
}

function mask(o, f) {
    setTimeout(function() {
      var v = mphone(o.value);
      if (v != o.value) {
        o.value = v;
      }
    }, 1);
}

function mphone(v) {
    var r = v.replace(/\D/g, "");
    r = r.replace(/^0/, "");
    if (r.length > 10) {
        r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
    } else if (r.length > 5) {
        r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
    } else if (r.length > 2) {
        r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
    } else {
        r = r.replace(/^(\d*)/, "($1");
    }
    return r;
}

function formatarData(data){
    let novaData = data.substring(10,16) + " em " + data.substring(8,10) + "/" + data.substring(5, 7) + "/"+ data.substring(0, 4)  ;
    return novaData.toString();
}

/*--------------------------------------------------- FUNÇÕES DE HTML/CSS ---------------------------------------------*/

// Ativa erro no formulário
function toggleErrorDesign(element, span, message = false){

    document.getElementById(element).classList.add('form-field-invalid-value');
    document.getElementById(span).style.display = 'block';

    if(message != false) document.getElementById(span).innerHTML = message;
    
    document.getElementById(element).addEventListener('click', e=>{
        document.getElementById(span).style.display = 'none';
        document.getElementById(element).classList.remove('form-field-invalid-value');
    });
}

function toggleConfigOption(option){ //

    let menuLis = [];
    let pageOptions = [];
    
    menuLis.push( document.getElementById('li-item-perfil'), document.getElementById('li-item-messages'), document.getElementById('li-item-send-image'), 
                document.getElementById('li-item-security'), document.getElementById('li-item-others')
    );

    pageOptions.push(document.getElementById('config-main-profile'), document.getElementById('config-main-messages'), document.getElementById('config-main-send-image'), 
                    document.getElementById('config-main-security'), document.getElementById('config-main-others')
    );

    for(i=0; i< menuLis.length; i++){

        if(i===option){
            menuLis[i].classList.add('config-menu-option-li-selected');
            pageOptions[i].style.display = 'block';
        }
        else{
            menuLis[i].classList.remove('config-menu-option-li-selected');
            pageOptions[i].style.display = 'none';
        }
    } 
}

// Verifica quais imagens do usuário estão preenchidas
function verificaImagensPreenchidas(){
    let imageCollection = document.getElementsByClassName("send-image-displayer");
    let uploadCollection = document.getElementsByClassName("send-empty-space");
    let photoArray =[];

    document.getElementById('send-delete-btn').style.display = 'none';

    for(i=0; i<imageCollection.length; i++){

        if(imageCollection[i].getAttribute('src').trim() === ""){
            uploadCollection[i].style.display = 'block';
            uploadCollection[i].addEventListener('click', e=>{
                document.getElementById("send-input-upload").click();
            });
        }
        else{
            photoArray.push(imageCollection[i]);
            imageCollection[i].addEventListener('click', e=>{
                selecionarDeletarImagem(e.target.id, photoArray);
            });
        }
    }
}
// Adiciona classe de seleção e permite deletar imagem
function selecionarDeletarImagem(photoClicked, photos){
    for(i=0; i<photos.length; i++){
        
        if(photoClicked === photos[i].id){
            
            document.getElementById(photoClicked).classList.add("send-selected-photo");
            document.getElementById(photoClicked).parentElement.classList.add("send-selected-photo-parent");
            document.getElementById('send-delete-btn').style.display = 'block';
        }
        else{
            document.getElementById(photos[i].id).classList.remove("send-selected-photo");
            document.getElementById(photos[i].id).parentElement.classList.remove("send-selected-photo-parent");
        }
    }
}

function carregaTodosEventosParaBotões(){

    document.getElementById("config-main-edit-data").addEventListener('click', e=>{
        document.getElementById("config-main-cancel-edit").style.display = 'block';
        document.getElementById("config-main-edit-data").innerHTML = "Salvar Dados";
        let fields = document.getElementsByClassName("form-field");
        for(let i=0; i<fields.length; i++){
            fields[i].style.filter = 'none'; 
            fields[i].style.pointerEvents = 'all';
        }
    });

    // Botão Cancelar Alteração de Dados 
    document.getElementById("config-main-cancel-edit").addEventListener('click', e=>{
        document.getElementById("config-main-cancel-edit").style.display = 'none';
        document.getElementById("config-main-edit-data").innerHTML = "Alterar Dados";

        let fields = document.getElementsByClassName("form-field");
        for(let i=0; i<fields.length; i++){
            fields[i].style.filter = 'brightness(0.9)';
            fields[i].style.pointerEvents = 'none';
        }
    });

    //Botão Editar Foto de Perfil
    document.getElementById('acc-p-edit-photo').addEventListener('click', e=>{
        modalTrocarFotoPerfil();
    });

    // Aplica evento de clique para todas as mensagens
    let messages = document.getElementsByClassName('messages-default-message');
    for(i=0; i<messages.length; i++){
        messages[i].addEventListener('click', e=>{
            mostrarDetalhesDaMensagem();
        });
    }

    //Postagem
    mostrarPostagem();
}

function selecionarConfiguracao(option){

    let menuButton = [];
    let pageConfig = [];

    menuButton.push(document.getElementById('config-submenu-geral'), document.getElementById('config-submenu-endereco'), document.getElementById('config-submenu-contato'), document.getElementById('config-submenu-redes-sociais'));

    pageConfig.push(document.getElementById('config-profile-geral'), document.getElementById('config-profile-endereco'), document.getElementById('config-profile-contato'), document.getElementById('config-profile-redes-sociais'));

    for(i=0; i<menuButton.length; i++){
        if(i===option){
            pageConfig[i].style.display = 'block';
            menuButton[i].classList.add('config-select-configuration-selected');
        }
        else{
            pageConfig[i].style.display = 'none';
            menuButton[i].classList.remove('config-select-configuration-selected');
        }
    }
}

// Abre / Fecha Modal Para Alterar Foto de Perfil
function modalTrocarFotoPerfil(){
    let modal = document.getElementById("modalChangePhoto");
    let span = document.getElementById("acc-span-close");
    let btnClose = document.getElementById("acc-btn-close-modal");
    
    modal.style.display = "block";
    span.onclick = function() {modal.style.display = "none";}
    btnClose.onclick = function() {modal.style.display = "none";}
    window.onclick = function(event) {if (event.target == modal) modal.style.display = "none";}
}

// Detalhes da Mensagem 
function mostrarPostagem(){
    
    let postagem = document.getElementsByClassName('spoiler-title');
    let btnVoltar = document.getElementById('voltar-detalhe');
    let filter = document.getElementsByClassName('post-select')[0];
    let btnNovaPostagem = document.getElementById('btn-nova-postagem');
    let btnVoltarNovaPostagem = document.getElementById('voltar-nova-postagem');

    let divComentarios = document.getElementById("append-commentary");
        
    for(i=0; i< postagem.length; i++){
        postagem[i].addEventListener('click', e =>{
            filter.disabled = true;
            btnNovaPostagem.disabled = true;
            document.getElementsByClassName('post-main')[0].style.display = 'none'; 
            document.getElementsByClassName('detail-post')[0].style.display = 'block';

            while(divComentarios.hasChildNodes()){
                divComentarios.removeChild(divComentarios.firstChild);
            }

            exibirDadosPostagem(e.target.id);
        });       
    } 

    btnVoltar.addEventListener('click', e =>{
        filter.disabled = false;
        btnNovaPostagem.disabled = false;
        document.getElementsByClassName('detail-post')[0].style.display = 'none';
        document.getElementsByClassName('post-main')[0].style.display = 'block'; 
    })

    btnNovaPostagem.addEventListener('click', e=>{
        filter.disabled = true;
        btnNovaPostagem.disabled = true;
        document.getElementsByClassName('post-main')[0].style.display = 'none'; 
        document.getElementsByClassName('new-post')[0].style.display = "block";
    });

    btnVoltarNovaPostagem.addEventListener('click', e=>{
        filter.disabled = false;
        btnNovaPostagem.disabled = false;
        document.getElementsByClassName('new-post')[0].style.display = "none";
        document.getElementsByClassName('post-main')[0].style.display = 'block'; 
    });
}
