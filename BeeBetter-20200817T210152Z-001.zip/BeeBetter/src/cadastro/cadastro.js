function toggleForm(page){

    document.getElementById("erro-conexao").style.display = 'none';

    let progressBar = document.getElementById('register-progress');
    let textInfo = document.getElementById('text-info');
    let step1 = document.querySelector(".step-1");
    let step2 = document.querySelector(".step-2");
    let step3 = document.querySelector(".step-3");
    let step4 = document.querySelector(".step-4");

    if(page == 1){
        progressBar.style.width = '0%';
        progressBar.innerHTML = '0%';
        textInfo.innerHTML = 'Cadastrar sua Instituição em nosso site é simples e rápido! Para começar, digite o nome da sua ONG.'
        step1.style.display = 'block';
        step2.style.display = 'none';
        document.querySelector("#titulo").innerHTML = 'CADASTRE SUA INSTITUIÇÃO';
    }
    if(page == 2){
        if(validarStep1()){
            progressBar.style.width = '25%';
            progressBar.innerHTML = '25%';
            textInfo.innerHTML = 'Ótimo! Agora conte-nos um pouco mais sobre a sua ONG.'
            step1.style.display = 'none';
            step2.style.display = 'block';
            step3.style.display = 'none';
            document.querySelector("#titulo").innerHTML = 'INFORMAÇÕES GERAIS';
        }
    }
    if(page == 3){
        if(validarStep2()){
            progressBar.style.width = '50%';
            progressBar.innerHTML = '50%';
            textInfo.innerHTML = 'Estamos quase lá! Preencha com seu endereço e informações para contato.'
            step2.style.display = 'none';
            step3.style.display = 'block';
            step4.style.display = 'none';
            document.querySelector("#titulo").innerHTML = 'CONTATO';
        }
    }
    if(page == 4){
        if(validarStep3()){
            progressBar.innerHTML = '75%';
            progressBar.style.width = '75%';
            textInfo.innerHTML = 'Para finalizar, escolha seu login e sua senha.'
            document.querySelector(".step-3").style.display = 'none';
            document.querySelector(".step-4").style.display = 'block';
            document.querySelector("#titulo").innerHTML = 'FINALIZAR';
        }
    }
    if(page == 5){
        progressBar.innerHTML = '100%';
        progressBar.style.width = '100%';
    }
}

function verificarCNPJ(cnpj){
    let dados = {cnpj: cnpj}
    let call = connectionAjax(dados, "7");
    return call.result;
}

function verificarEmail(email){
    let dados = {email: email}
    let call = connectionAjax(dados, "8");
    return call.result;
}

function verificarLogin(login){
    let dados = {login: login}
    let call = connectionAjax(dados, "9");
    return call.result;
}

function validarCNPJ(cnpj) {
 
    cnpj = cnpj.replace(/[^\d]+/g,'');
 
    if(cnpj == '') return false;
     
    if (cnpj.length != 14)
        return false;
 
    // Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" || 
        cnpj == "11111111111111" || 
        cnpj == "22222222222222" || 
        cnpj == "33333333333333" || 
        cnpj == "44444444444444" || 
        cnpj == "55555555555555" || 
        cnpj == "66666666666666" || 
        cnpj == "77777777777777" || 
        cnpj == "88888888888888" || 
        cnpj == "99999999999999")
        return false;
         
    // Valida DVs
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0,tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;
         
    tamanho = tamanho + 1;
    numeros = cnpj.substring(0,tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11
    ;
    if (resultado != digitos.charAt(1)) 
          return false;
           
    return true;
    
}

function validarStep1(){ 

    /*var*/ razaoSocial = document.getElementById("field-razaoSocial").value;
    /*var*/ cnpj = document.getElementById("field-cnpj").value;
    var control = true;

    if(razaoSocial == ""){
        toggleErrorDesign('field-razaoSocial', 'span-error-nome');
        control = false;
    }

    if (cnpj != "" && !validarCNPJ(cnpj)){
        toggleErrorDesign('field-cnpj', 'span-error-cnpj', 'O CNPJ informado é Inválido');
        control = false;
    }

    if(cnpj != "" && validarCNPJ(cnpj) && verificarCNPJ(cnpj) === true){
        toggleErrorDesign('field-cnpj', 'span-error-cnpj', 'O CNPJ informado já está cadastrado');
        control = false;
    }

    return control
}

function validarStep2(){ 

    /*var*/ causaSocial = document.getElementById("field-causa-social").value;
    /*var*/ cep = document.getElementById("field-cep").value;
    /*var*/ rua = document.getElementById("field-rua").value;
    /*var*/ numero = document.getElementById("field-numero").value;
    /*var*/ bairro = document.getElementById("field-bairro").value;
    /*var*/ cidade = document.getElementById("field-cidade").value;
    /*var*/ uf = document.getElementById("field-uf").value;
    var control = true;

    if (causaSocial == "Causa Social"){
        toggleErrorDesign('field-causa-social', 'span-error-causa-social', 'Selecione a Causa Social.');
        control = false;
    }

    if(cep != "" && cep.length < 8 || cep == ""){
        toggleErrorDesign('field-cep', 'span-error-cep', 'O número do CEP é inválido!');
        control = false;
    }

    if(rua == "") {
        toggleErrorDesign('field-rua', 'span-error-rua');
        control = false;
    }

    if(numero == "") {
        toggleErrorDesign('field-numero', 'span-error-numero');
        control = false;
    }

    if(bairro == "") {
        toggleErrorDesign('field-bairro', 'span-error-bairro');
        control = false;
    }

    if(cidade == "") {
        toggleErrorDesign('field-cidade', 'span-error-cidade');
        control = false;
    }

    if(uf == "UF") {
        toggleErrorDesign('field-uf', 'span-error-uf');
        control = false;
    }

   return control;
}

function validarStep3(){ 

    /*var*/ email = document.getElementById('field-email').value;
    /*var*/ foneFixo = document.getElementById('field-fone-fixo').value.replace(/[^0-9]/g, "");
    /*var*/ whatsapp = document.getElementById('field-whatsapp').value.replace(/[^0-9]/g, "");
    var control = true;

    if (foneFixo != "" && foneFixo.length < 10 ) {
        toggleErrorDesign('field-fone-fixo', 'span-error-fone-fixo', 'O número de telefone é inválido!');
        control = false;
    } 

    if (whatsapp != ""  && whatsapp.length < 10) {
        toggleErrorDesign('field-whatsapp', 'span-error-whatsapp', 'O número de telefone é inválido!');
        control = false;
    }

    if(email == "") {
        toggleErrorDesign('field-email', 'span-error-email');
        control = false;
    }

    if (email != "" && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
        toggleErrorDesign('field-email', 'span-error-email', 'O email informado é inválido.');
        control = false;
    }

    if (email != "" && /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email) && verificarEmail(email) === true) {
        toggleErrorDesign('field-email', 'span-error-email', 'O email informado já está cadastrado.');
        control = false;
    }

    return control;
    
}

function validarStep4(){

    /*var*/ login = document.getElementById("field-login").value;
    /*var*/ senha = document.getElementById("field-senha").value;
    /*var*/ confSenha = document.getElementById("field-confSenha").value;
    var control = true;

    if(login == ""){
        toggleErrorDesign('field-login', 'span-error-login');
        control = false;
    }
    if(senha == ""){
        toggleErrorDesign('field-senha', 'span-error-senha');
        control = false;
    }
    if(confSenha == ""){
        toggleErrorDesign('field-confSenha', 'span-error-confSenha');
        control = false;
    }
    if(senha !== confSenha){
        toggleErrorDesign('field-senha', 'span-error-senha', 'As senhas informadas devem ser iguais.');
        toggleErrorDesign('field-confSenha', 'span-error-senha', 'As senhas informadas devem ser iguais.');
        control = false;
    }
    if(login !== "" && login.length < 5 ){
        toggleErrorDesign('field-login', 'span-error-login', 'O login deve ser conter mais de 5 caracteres.');
        control = false;
    }
    if(senha !== "" && senha.length < 5 ){
        toggleErrorDesign('field-senha', 'span-error-senha', 'A senha deve ser conter mais de 5 caracteres.');
        toggleErrorDesign('field-confSenha', 'span-error-senha', 'A senha deve ser conter mais de 5 caracteres.');
        control = false;
    }

    if(login !== "" && login.length >= 5 && verificarLogin(login) === true){
        toggleErrorDesign('field-login', 'span-error-login', 'O login informado já está cadastrado.');
        control = false;
    }

    return control;
}

function finalizar(){

    if (validarStep4()){

        foneFixo = foneFixo.replace(/[^0-9]g/, "");
        whatsapp = whatsapp.replace(/[^0-9]g/, "");

        let imgPerfil = "https://firebasestorage.googleapis.com/v0/b/beebetter-394f3.appspot.com/o/Imagens_site%2Fno-image.jpg?alt=media&token=b225f1cf-fac8-44b0-98fd-320cb904d004";
        let nomeImg = "padrao";

        var dados = {
            login: login, 
            senha: senha,
            razao_social: razaoSocial,
            email: email,
            cnpj: cnpj,
            causa_social: causaSocial, 
            cep: cep,
            rua: rua, 
            numero_residencial: numero,
            bairro: bairro, 
            cidade: cidade,
            uf: uf,
            foneFixo: foneFixo,
            whatsapp: whatsapp,
            
            img: encodeURIComponent(imgPerfil),
            nomeImg: nomeImg
        }

        console.log(dados);

        let call = connectionAjax(dados, "1");

        if(call.error === false){
            //Chama modal de sucesso
            toggleForm(5);
            modalEvents();
        } else {
            console.log(call.error);
            alerta(true);
        }

    }
}

function toggleErrorDesign(element, span, message = false){

    document.getElementById(element).classList.add('form-field-invalid-value');
    document.getElementById(span).style.display = 'block';

    if(message != false) document.getElementById(span).innerHTML = message;
    
    document.getElementById(element).addEventListener('click', e=>{
        document.getElementById(span).style.display = 'none';
        document.getElementById(element).classList.remove('form-field-invalid-value');
    });
}

function alerta(condicao){

    if (condicao === true){
        document.getElementById("erro-conexao").style.display = "block";
    } 

    if(condicao === false){
        document.getElementById("erro-conexao").style.display = "none";
    }


}

// Método para realizar comunicação com o backend
function connectionAjax(dados, modo = "404"){
    try{        
        let res = JSON.parse(ajax(dados, modo));
        
        console.log("Retorno ajax:");
        console.log(res);
        return res;
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}

function writeUF(uf){
    let est = document.querySelector("#uf-name");
    if(uf ==="AC") est.value = "Acre";
    if(uf ==="AL") est.value = "Alagoas";
    if(uf ==="AP") est.value = "Amapá";
    if(uf ==="AM") est.value = "Amazonas";
    if(uf ==="BA") est.value = "Bahia";
    if(uf ==="CE") est.value = "Ceará";
    if(uf ==="DF") est.value = "Distrito Federal";
    if(uf ==="ES") est.value = "Espírito Santo";
    if(uf ==="GO") est.value = "Goiás";
    if(uf ==="MA") est.value = "Maranhão";
    if(uf ==="MT") est.value = "Mato Grosso";
    if(uf ==="MS") est.value = "Mato Grosso do Sul";
    if(uf ==="MG") est.value = "Minas Gerais";
    if(uf ==="PA") est.value = "Pará";
    if(uf ==="PB") est.value = "Paraíba";
    if(uf ==="PR") est.value = "Paraná";
    if(uf ==="PE") est.value = "Pernambuco";
    if(uf ==="PI") est.value = "Piauí";
    if(uf ==="RJ") est.value = "Rio de Janeiro";
    if(uf ==="RN") est.value = "Rio Grande do Norte";
    if(uf ==="RS") est.value = "Rio Grande do Sul";
    if(uf ==="RO") est.value = "Rondônia";
    if(uf ==="RR") est.value = "Roraima";
    if(uf ==="SC") est.value = "Santa Catarina";
    if(uf ==="SP") est.value = "São Paulo";
    if(uf ==="SE") est.value = "Sergipe";
    if(uf ==="TO") est.value = "Tocantins";
}

// Ativa gif de carregamento
document.querySelector('#field-cep').addEventListener('change', async () => {
    try{
        document.getElementById('cep-loading-gif').style.display = 'block';

        let cep = document.querySelector('#field-cep').value;
        let url = `https://cors-anywhere.herokuapp.com/http://apps.widenet.com.br/busca-cep/api/cep/${cep}.json`;
    
        console.log(url);
    
        const json = await $.getJSON(url);
    
        console.log(json);

        if(!json.ok) toggleErrorDesign('field-cep', 'span-error-cep', 'O valor de CEP informado não existe.');
        
        document.getElementById('cep-loading-gif').style.display = 'none';

        if(json.address) document.querySelector('#field-rua').value = json.address;
        else return;
    
        if(json.city) document.querySelector('#field-cidade').value = json.city;
    
        if(json.district) document.querySelector('#field-bairro').value = json.district;
    
        if(json.state){
            const select = document.querySelector('#field-uf');
            let option;
            for (const opt of select.children) {
                if(opt.value == json.state) option = opt.value;
            }
            select.value = option;
            writeUF(option);
        } 
        
    } catch(err){

        toggleErrorDesign('field-cep', 'span-error-cep', 'Não foi possível encontrar informações sobre o CEP. Tente novamente.');
        document.getElementById('cep-loading-gif').style.display = 'none';

        console.log(err);
    }
});

function modalEvents(){
    var modal = document.getElementById("modal-success-register");
    var btnFechar = document.getElementById("btn-giveup");
    var btnLogin = document.getElementById("btn-letsgo");

    modal.style.display = "block";

    btnFechar.addEventListener('click', e=>{
        window.location.href = '/BeeBetter/';
    });

    btnLogin.addEventListener('click', e=>{
        window.location.href = '/BeeBetter/login';
    });
}

function isNumberKey(evt) {
    
    var charCode = (evt.which) ? evt.which : event.keyCode

    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

    return true;
}
// Mascara de Telefone
function mask(o, f) {
    setTimeout(function() {
      var v = mphone(o.value);
      if (v != o.value) {
        o.value = v;
      }
    }, 1);
}
function mphone(v) {
    var r = v.replace(/\D/g, "");
    r = r.replace(/^0/, "");
    if (r.length > 10) {
        r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
    } else if (r.length > 5) {
        r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
    } else if (r.length > 2) {
        r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
    } else {
        r = r.replace(/^(\d*)/, "($1");
    }
    return r;
}


