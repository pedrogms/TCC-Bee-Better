window.onload = function(){

    carregarInstituicoes();
    carregarUltimas();
    loadCausaSocialCards();
}

function carregarInstituicoes(){
    let dados = {};
    let call = connectionAjax(dados, "5");

    call.data.map((ong, index)=>{
        // console.log(index);
        // console.log(ong);

        if(index < 5){
            let card = `
                <div class="destaque-card"  id="${ong.id_ong}" onclick='detalhesOng(${ong.id_ong})'>
                    <div class="destaque-img">
                        <img src="${ong.imagens[0].imagem}">
                    </div>
                    <hr>
                    <div class="card-text destaque-nome-inst">${ong.razao_social}</div>
                    <div class="card-text destaque-local-inst">${ong.cidade} - ${ong.uf}</div>
                    <div class="card-text destaque-causa-inst" title="Causa Social">${ong.causa_social}</div>
                </div>
            `;

            $("#row-cards").append(card);
        }
    });

}

function carregarUltimas(){
    let dados = {};
    let call = connectionAjax(dados, "5");

    call.data.reverse().map((ong, index)=>{

        if(index < 5){
            let card = `
                <div class="destaque-card"  id="${ong.id_ong}" onclick='detalhesOng(${ong.id_ong})'>
                    <div class="destaque-img">
                        <img src="${ong.imagens[0].imagem}">
                    </div>
                    <hr>
                    <div class="card-text destaque-nome-inst">${ong.razao_social}</div>
                    <div class="card-text destaque-local-inst">${ong.cidade} - ${ong.uf}</div>
                    <div class="card-text destaque-causa-inst" title="Causa Social">${ong.causa_social}</div>
                </div>
            `;

            $("#row-cards-lasts").append(card);
        }
    });

}

function loadCausaSocialCards(){

    let causaSocialCards = document.getElementsByClassName("find-social-cause-card");
    

    for(i = 0; i < causaSocialCards.length; i++){


        causaSocialCards[i].addEventListener('click', e=>{

            sessionStorage.setItem("queryPesquisa", e.target.innerText);
            window.location.href = "/BeeBetter/buscar";

        });
    }

}

function detalhesOng(id){  
    sessionStorage.setItem("id", id);
    window.location.href = "/BeeBetter/detalhes";
}

// Método para realizar comunicação com o backend
function connectionAjax(dados, modo = "404"){
    try{        
        let res = ajax(dados, modo);
        
        console.log("Retorno ajax:");
        console.log(JSON.parse(res));
        return JSON.parse(res);
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}