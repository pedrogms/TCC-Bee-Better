$(document).ready(function(){
    
    let id = sessionStorage.getItem("id");

    if(!id){
        window.location.href = "/BeeBetter/vitrine";
    } else{
        carregarDados();
        iniciaTodosOsMetodosCss();
    }
});


function carregarDados(){

    let dados = {
        id: sessionStorage.getItem("id").toString()
    } 

    let call = connectionAjax(dados, "4");

    if(call.error === false){

        let ong = call.userData;

        document.getElementById("title-page").innerHTML = ong.razao_social;
        document.getElementById("inst-name").innerHTML = ong.razao_social;
        document.getElementById("post-name").innerHTML = ong.razao_social;

        document.getElementById("info-causa-social").innerHTML = ong.causa_social;
        document.getElementById("info-cidade-uf").innerHTML = `Localizada em <strong> ${ong.cidade} - ${ong.uf} </strong>`;

        if(ong.descricao === null || ong.descricao === ""){
            ong.descricao = " A instituição " + ong.razao_social + " não possui nenhuma descrição!";
        } 
        document.getElementById("description-text").innerHTML = ong.descricao.replace(/[\n]/g, "<br>");

        let end = ong.rua + ", " + ong.numero_residencial + " - " + ong.bairro + ", " + ong.cidade + " - " + ong.uf;

        carregarContatos(end, ong.email, ong.telefone_fixo, ong.whatsapp1, ong.whatsapp2, ong.facebook, ong.twitter, ong.instagram, ong.youtube);
        carregarImagens(ong.imagens);
        carregarPostagens(ong.posts);

        carregarOutrasOngs();

    }
}

function carregarContatos(endereco, email, telefone_fixo, whatsapp1, whatsapp2, facebook, twitter, instagram, youtube){

    document.getElementById("media-email").innerHTML = email;
    document.getElementById("media-endereco").innerHTML = endereco;

    if(telefone_fixo === null || telefone_fixo === "" ){
        telefone_fixo = null;
        document.getElementById("media-phone").parentElement.style.display = "none";
    }
    document.getElementById("media-phone").innerHTML = adicionarCharFone(telefone_fixo);

    if(whatsapp1 === null || whatsapp1 === "" ){
        whatsapp1 = null;
        document.getElementById("media-whatsapp").parentElement.style.display = "none";
    }
    document.getElementById("media-whatsapp").innerHTML = adicionarCharFone(whatsapp1);

    if(whatsapp2 === null || whatsapp2 === ""){
        whatsapp2 = null;
        document.getElementById("media-whatsapp-two").parentElement.style.display = "none";
    }
    document.getElementById("media-whatsapp-two").innerHTML = adicionarCharFone(whatsapp2);


    if (facebook === null || facebook === ""){
        facebook = "#";
        document.getElementById("media-facebook").style.display = "none";
    }
    document.getElementById("media-facebook").href = facebook;

    if (twitter === null || twitter === ""){
        twitter = "#";
        document.getElementById("media-twitter").style.display = "none";
    }
    document.getElementById("media-twitter").href = twitter;

    if (instagram === null || instagram === ""){
        instagram = "#";
        document.getElementById("media-instagram").style.display = "none";
    }
    document.getElementById("media-instagram").href = instagram;

    if (youtube === null || youtube === ""){
        youtube = "#";
        document.getElementById("media-youtube").style.display = "none";
    }
    document.getElementById("media-youtube").href = youtube;
}

function carregarImagens(imagens){

    document.getElementById("main-image").src = imagens[0].imagem;

    imagens.map((imagem)=>{
        
        let miniatura = `
            <div class="mini-box">  
                <img src="${imagem.imagem}">
            </div>
        `;

        $("#linha-miniaturas").append(miniatura);
    }); 
}

function carregarPostagens(postagens){

    globalPosts = postagens;

    postagens.reverse().map((post)=>{

        try{

            let postagem = `
                <div class="row post-preview">
                    <div class="col-10">
                        <p class="post-prev-title post-prev-color" id="${post.id_post}"> ${post.titulo} </p>
                        <p class="post-prev-text">${post.postagem.substring(0, 30)}...</p>
                    </div>

                    <div class="col-2 post-prev-date ">
                        <span class="post-prev-color">${formatarData(post.dta_post)}</span>
                    </div>
                </div>
            `;

            $("#linha-postagens").append(postagem);

        }
        catch(e){
        }

    });
}

function detalhesPostagem(id){
    globalPosts.map((post)=>{
       
        if(post.id_post.toString() === id.toString()){

            document.getElementById("post-title").innerHTML = post.titulo;
            document.getElementById("post-text").innerHTML = post.postagem.replace(/[\n]/g, "<br>");
    
            post.comments.map((comentario)=>{
    
                let comment = `
                    <div class="comment-block">
                        <div class="com-top">
                            <span id="com-author">${comentario.nome}</span>
                            <span id="com-date-time">${formatarData(comentario.dta_comentario)}</span>
                        </div>
                        <div id="com-text">
                            ${comentario.comentario.replace(/[\n]/g, "<br>")}
                        </div>
                    </div>
                `;
    
                $("#append-comment").append(comment);
            });
        }

    });
}

function enviarComentario(){
    let nome = document.getElementById("field-nome-comentario").value.toString();
    let email = document.getElementById("field-email-comentario").value.toString();
    let comentario = document.getElementById("field-comentario").value.toString();
    let id_post = document.getElementsByClassName("modal")[0].id.replace(/[^0-9]/g, "");

    let controle = true;

    if(nome === ""){
        controle = false;
    }
    if(email === ""){
        controle = false;
    }
    if(comentario === ""){
        controle = false;
    }

    if(controle === true){
        let dados = {
            id_post: id_post,
            nome: nome,
            email: email,
            comentario: comentario
        }
        let call = connectionAjax(dados, "16");

        if(call.error === false){
            alert("Comentário inserido com sucesso!");
            window.location.reload();
        }
    }

}

function adicionarCharFone(fone){

    let newFone = "";

    if(fone === null){
        newfone = null;
    }

    try{
        if(fone.length === 10){
            newFone = "(" + fone.substring(0, 2) + ") " + fone.substring(2,6) + "-" + fone.substring(6, 11);
        }
    
        if(fone.length === 11){
            newFone = "(" + fone.substring(0, 2) + ") " + fone.substring(2,7) + "-" + fone.substring(7, 12);
        }
    } catch(error){

    }
    
    return newFone.toString();
}

function formatarData(data){
    let novaData = data.substring(10,16) + " em " + data.substring(8,10) + "/" + data.substring(5, 7) + "/"+ data.substring(0, 4)  ;
    return novaData.toString();
}

function carregarOutrasOngs(){

    let call = connectionAjax({}, "5");

    if(call.error === false){

        call.data.reverse().map((ong, index)=>{

            if(index < 10){
                let card = `
                    <div class="destaque-card"  id="${ong.id_ong}" onclick='detalhesOng(${ong.id_ong})'>
                        <div class="destaque-img">
                            <img src="${ong.imagens[0].imagem}">
                        </div>
                        <hr>
                        <div class="card-text destaque-nome-inst">${ong.razao_social}</div>
                        <div class="card-text destaque-local-inst">${ong.cidade} - ${ong.uf}</div>
                        <div class="card-text destaque-causa-inst" title="Causa Social">${ong.causa_social}</div>
                    </div>
                `;
    
                $("#row-cards").append(card);
            }

        });

    }
}

function detalhesOng(id){

    sessionStorage.setItem("id", id);

    window.location.reload();

}

// Método para realizar comunicação com o backend
function connectionAjax(dados, modo = "404"){
    try{    
        let res = ajax(dados, modo);    

        console.log("Retorno ajax:");
        console.log(JSON.parse(res));
        return JSON.parse(res);
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}
        
/* -------------- HTML E CSS -------------- */
function iniciaTodosOsMetodosCss(){
    trocarImagemDisplay();
    modal();
}

//Evento para trocar imagem em destaque
function trocarImagemDisplay(){
    let mainImage = document.getElementById('main-image');
    let miniBox = document.getElementsByClassName('mini-box');

    for(i=0; i < miniBox.length; i++){
        miniBox[i].addEventListener('click', e=>{
            mainImage.src = e.target.currentSrc;
        });
    }
}

function modal(){
    var modal = document.getElementById("myModal");

    var span = document.getElementsByClassName("close")[0];

    let posts = document.getElementsByClassName('post-prev-title');

    for(i=0; i < posts.length; i++){
        posts[i].addEventListener('click', e=>{
            detalhesPostagem(e.target.id);
            modal.style.display = "block";
            modal.id = `modal-${e.target.id}`;
        });
    }

    span.onclick = function() {
        modal.style.display = "none";

        let comentarios = document.getElementById("append-comment");

        while(comentarios.hasChildNodes()){
            comentarios.removeChild(comentarios.firstChild);
        }
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

}

