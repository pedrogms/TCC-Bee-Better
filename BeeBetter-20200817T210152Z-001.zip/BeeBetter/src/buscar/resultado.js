window.onload = function(){

    let query = sessionStorage.getItem("queryPesquisa");
    
    
    if(!query){
        window.location.href = "/BeeBetter/";
    } else{

        document.getElementById("query").innerHTML = query;

        let dados = {query: query};
        let call = connectionAjax(dados, "13");

        console.log(call);

        allOngs = call.data;

        document.getElementById("total-resultados").innerHTML = `Foram encontrados ${allOngs.length} resultado(s) para a pesquisa.`;

        carregarResultados(call.data);
    }

}

function carregarResultados(ongs){

    if(ongs.length === 0){

        document.getElementById("no-result").style.display = "block";

    } else{

        ongs.map((ong)=>{

            ong.descricao = (ong.descricao === null) ? `A ONG ${ong.razao_social} não possui descrição.` : ong.descricao.substring(0, 330) + "...";

            let card = `
                <div class="row result-card-inst" id="${ong.id_ong}" onclick="detalhesOng(${ong.id_ong})">
                    <div class="col-4 result-card-photo">
                        <img src="${ong.imagens[0].imagem}">
                    </div>
                    <div class="col-8">
                        <div class="row">
                            <p class="result-card-title">${ong.razao_social}</p>
                        </div>
                        <div class="row result-card-desc">
                            ${ong.descricao}
                        </div>
                        <div class="row result-card-tags">
                            <ul class="d-flex justify-content-around result-card-ul">
                                <li title="Pesquisar por causa social">${ong.causa_social}</li>
                                <li title="E-mail"> ${ong.email}</li>
                                <li title="Cidade"> ${ong.cidade}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            `;

            $("#resultadosPesquisa").append(card);

        });
    }

}

function detalhesOng(id){  
    sessionStorage.setItem("id", id);
    window.location.href = "/BeeBetter/detalhes";
}

function filtroCausaSocial(causaSocial){

    divResults = document.getElementById("resultadosPesquisa");

    while(divResults.hasChildNodes()){

        divResults.removeChild(divResults.firstChild);
        
    }

    let counter = 0;

    allOngs.map((ong)=>{
        
        if(ong.causa_social === causaSocial || causaSocial === "Todas"){
            
            ong.descricao = (ong.descricao === null) ? `A ONG ${ong.razao_social} não possui descrição.` : ong.descricao.substring(0, 330) + "...";

            let card = `
                <div class="row result-card-inst" id="" onclick="detalhesOng(${ong.id_ong})">
                    <div class="col-4 result-card-photo">
                        <img src="${ong.imagens[0].imagem}">
                    </div>
                    <div class="col-8">
                        <div class="row">
                            <p class="result-card-title">${ong.razao_social}</p>
                        </div>
                        <div class="row result-card-desc">
                            ${ong.descricao}
                        </div>
                        <div class="row result-card-tags">
                            <ul class="d-flex justify-content-around result-card-ul">
                                <li title="Pesquisar por causa social">${ong.causa_social}</li>
                                <li title="E-mail"> ${ong.email}</li>
                                <li title="Cidade"> ${ong.cidade}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            `;

            $("#resultadosPesquisa").append(card);
            counter = counter + 1;
        }

    });

    document.getElementById("total-resultados").innerHTML = `Foram encontrados ${counter} resultado(s) para a pesquisa.`;


    if(!divResults.hasChildNodes()){

        document.getElementById("no-result").style.display = "block";

    } else{
        document.getElementById("no-result").style.display = "none";
    }

}

function filtroLocalizacao(estado){

    if(estado ==="Acre") estado = "AC";
    if(estado ==="Alagoas") estado = "AL";
    if(estado ==="Amapá") estado = "AP";
    if(estado ==="Amazonas") estado = "AM";
    if(estado ==="Bahia") estado = "BA";
    if(estado ==="Ceará") estado = "CE";
    if(estado ==="Distrito Federal") estado = "DF";
    if(estado ==="Espírito Santo") estado = "ES";
    if(estado ==="Goiás") estado = "GO";
    if(estado ==="Maranhão") estado = "MA";
    if(estado ==="Mato Grosso") estado = "MT";
    if(estado ==="Mato Grosso do Sul") estado = "MS";
    if(estado ==="Minas Gerais") estado = "MG";
    if(estado ==="Pará") estado = "PA";
    if(estado ==="Paraíba") estado = "PB";
    if(estado ==="Paraná") estado = "PR";
    if(estado ==="Pernambuco") estado = "PE";
    if(estado ==="Piauí") estado = "PI";
    if(estado ==="Rio de Janeiro") estado = "RJ";
    if(estado ==="Rio Grande do Norte") estado = "RN";
    if(estado ==="Rio Grande do Sul") estado = "RS";
    if(estado ==="Rondônia") estado = "RO";
    if(estado ==="Roraima") estado = "RR";
    if(estado ==="Santa Catarina") estado = "SC";
    if(estado ==="São Paulo") estado = "SP";
    if(estado ==="Sergipe") estado = "SE";
    if(estado ==="Tocantins") estado = "TO";

    divResults = document.getElementById("resultadosPesquisa");

    while(divResults.hasChildNodes()){

        divResults.removeChild(divResults.firstChild);
        
    }

    let counter = 0;

    allOngs.map((ong)=>{
        
        if(ong.uf === estado || estado === "Todas"){
            
            ong.descricao = (ong.descricao === null) ? `A ONG ${ong.razao_social} não possui descrição.` : ong.descricao.substring(0, 330) + "...";

            let card = `
                <div class="row result-card-inst" id="" onclick="detalhesOng(${ong.id_ong})">
                    <div class="col-4 result-card-photo">
                        <img src="${ong.imagens[0].imagem}">
                    </div>
                    <div class="col-8">
                        <div class="row">
                            <p class="result-card-title">${ong.razao_social}</p>
                        </div>
                        <div class="row result-card-desc">
                            ${ong.descricao}
                        </div>
                        <div class="row result-card-tags">
                            <ul class="d-flex justify-content-around result-card-ul">
                                <li title="Pesquisar por causa social">${ong.causa_social}</li>
                                <li title="E-mail"> ${ong.email}</li>
                                <li title="Cidade"> ${ong.cidade}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            `;

            $("#resultadosPesquisa").append(card);
            counter = counter + 1;
        }

    });

    document.getElementById("total-resultados").innerHTML = `Foram encontrados ${counter} resultado(s) para a pesquisa.`;

    if(!divResults.hasChildNodes()){

        document.getElementById("no-result").style.display = "block";

    } else{
        document.getElementById("no-result").style.display = "none";
    }

}

function connectionAjax(dados, modo = "404"){
    try{        
        let res = ajax(dados, modo);
        
        console.log("Retorno ajax:");
        console.log(JSON.parse(res));
        return JSON.parse(res);
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}