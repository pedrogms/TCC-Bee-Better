$(document).ready(()=>{

    if(sessionStorage.getItem("logado")){
        window.location.href="/BeeBetter/conta";
    }
});


function logar(){

    var login = document.getElementById('field-login').value;
    var senha = document.getElementById('field-senha').value;
    let control = true;

    if(login === ""){
        toggleErrorDesign('field-login', 'span-error-login');
        control = false;
    }
    if(senha === ""){
        toggleErrorDesign('field-senha', 'span-error-senha');
        control = false;
    }

    if(control === true){

        let dados = {login: login, senha: senha};

        let call = connectionAjax(dados, "6");

        if(call.error === false){
    
            //Executar procedimento para encaminhamento de login
            sessionStorage.setItem("logado", true);
            sessionStorage.setItem("id_usuario_logado", call.id_ong);

            window.location.href="/BeeBetter/conta";

        } else{
            
            document.getElementById("error-login").style.display = "block";
            toggleErrorDesign('field-login', 'span-error-login', "error-login-senha");
            toggleErrorDesign('field-senha', 'span-error-senha', "error-login-senha");

            console.log(call.error);
        }
    }
}

function recuperarEmail(email){
    //console.log(email);

    if(email ==""){
        toggleErrorDesign('field-rec-email', 'span-error-rec-email');
        return false;
    }
    if(email !="" && !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)){
        toggleErrorDesign('field-rec-email', 'span-error-rec-email', 'O email informado é inválido!');
        return false;
    }

    var dados = {email: email};

    let call = connectionAjax(dados, "17");
    let state = false;

    if(call.error === false){
        state = true;
    }
    else{
        console.log(call.error);
        toggleErrorDesign('field-rec-email', 'span-error-rec-email', call.error);
        state = false;
    }

    return state;
}

// Método para realizar comunicação com o backend
function connectionAjax(dados, modo = "404"){
    try{        
        let res = JSON.parse(ajax(dados, modo));
        
        console.log("Retorno ajax:");
        console.log(res);
        return res;
    }
    catch(err){
        console.log(err);
        return {success:false, error: "Erro ao realizar a conexão Ajax"}
    };
}

function toggleErrorDesign(element, span, message = false){

    document.getElementById(element).classList.add('form-field-invalid-value');
    

    if(message != false && message != "error-login-senha"){
        document.getElementById(span).innerHTML = message;
        document.getElementById(span).style.display = 'block';
    }

    if(message === "error-login-senha"){
        document.getElementById(element).classList.add('form-field-invalid-value');
    }
    
    
    document.getElementById(element).addEventListener('click', e=>{
        document.getElementById(span).style.display = 'none';
        document.getElementById(element).classList.remove('form-field-invalid-value');
    });
}

//Modal Esqueceu senha
function modalEsqueceuSenha(){
    var modal = document.getElementById("modal-forget-password");
    var msgRecover = document.getElementById('recover-password');
    var msgSuccessRecover = document.getElementById('recover-msg-success');
    var btnCancelar = document.getElementById("btn-cancel-pass");
    var btnEnviar = document.getElementById("btn-send-pass");
    var btnEntendi = document.getElementById("btn-end-pass");
    var textSentEmail = document.getElementById('nome-email');

    modal.style.display = "block";
    window.onclick = function(event) {
        if (event.target == modal) {modal.style.display = "none"; clearModal();}
    }
    btnEnviar.addEventListener('click', e=>{   
        var valueEmail = document.getElementById('field-rec-email').value;
        if (recuperarEmail(valueEmail) == true){
            msgRecover.style.display = 'none';
            msgSuccessRecover.style.display = 'block';
            textSentEmail.innerHTML = valueEmail;
        } else{
            //Mensagem dizendo que não foi possível recuperar o email
        }
    });
    btnCancelar.addEventListener('click', e=>{
        modal.style.display = 'none';
        clearModal();
    });
    btnEntendi.addEventListener('click', e=>{
        modal.style.display = 'none';
    });
}

function clearModal(){
    document.getElementById('field-rec-email').value = "";
    document.getElementById('span-error-rec-email').style.display = 'none';
    document.getElementById('field-rec-email').classList.remove('form-field-invalid-value');
}