<?php

include "../backend/banco.php";

$mode = $_REQUEST["mode"] ?? '404';
$response = array("error" => true);

 /* 
    Lista de todas as operações:
    
    1 - Insere Organização no banco -- ["login", "senha", "razao_social", "email", "cnpj", "causa_social", "cep", "numero_residencial", "bairro", "cidade", "uf", "img", "nomeImg"]
    2 - Atualiza informações da Organização -- ["id"]
    3 - Desativa cadastro da organização -- ["id"]
    4 - Seleciona informações de uma organização específica -- ["id"]
    5 - Seleciona informações de todas as organizações
    6 - Realiza login da organização -- ["login", "senha"]
    7 - Verifica se CNPJ já está cadastrado -- ["cnpj"]
    8 - Verifica se email já está cadastrado -- ["email"]
    9 - Verifica se login já está cadastrado -- ["login"]

    ---------- Imagens ----------

    10 - Insere imagem enviada pela organização
    11 - Atualiza imagem enviada pela organização
    12 - Remove imagem enviada pela organização


    ---------- Recuperar Senha ---------
    17 -  Envia email de recuperação de senha

 */ 

switch($mode){  

    case "1": // Insere organização no banco
        $fields = ["login", "senha", "razao_social", "email", "cnpj", "causa_social", "cep", "numero_residencial", "bairro", "rua", "cidade", "uf", "foneFixo", "whatsapp", "img", "nomeImg"];

        if(areSet($fields)){

            $dados = json_encode(postData($fields), JSON_UNESCAPED_UNICODE);
            $query = "CALL sp_inserirOng('$dados')";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "2": // Atualiza informações da organização
        $fields = ["id", "razao_social", "senha", "email", "cnpj", "causa_social", "cep", "rua", "numero_residencial", "bairro", "cidade", "uf", "telefone_fixo", "whatsapp1", "whatsapp2", "facebook", "instagram", "youtube", "twitter"];

        if(areSet(["id"])){

            $dados = json_encode(postData($fields), JSON_UNESCAPED_UNICODE);
            $query = "CALL sp_alterarOng('$dados')";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

            if(areSet(["descricao"])){
                $dados = postData(["id", "descricao"]);
                $query = "UPDATE tb_organizacao SET descricao='$dados->descricao' WHERE id_ong='$dados->id';";
                $result = query($query);
                array_push($response, ["desc_error"=>($result === true) ? false : true]);
            }

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }     

    break;

    case "3": // Desativa/Reativa cadastro da organização
        $fields = ["id", "ativo"];

        if(areSet($fields)){

            $dados = postData($fields);
            $dados = json_encode($dados);
            $query = "CALL sp_alterarOng('$dados')";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "4": // Seleciona informações de uma organização específica
        $fields = ["id"];

        if(areSet($fields)){

            $dados = postData($fields);
            $query = "CALL sp_pesquisarOng('$dados->id')";
            $result = formatImages(select($query));
            $result = addComents($result);
            $usuarioEncontrado = sizeof($result) > 0;

            $response = array("error" => ($usuarioEncontrado === true) ? false : true, "userData" => $result[0]);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "5": // Seleciona informações de todas as organizações

        $query = "SELECT ong.id_ong, ong.razao_social, ong.causa_social, ong.email, ong.cnpj, ong.descricao, 
        ong.cep, ong.rua, ong.numero_residencial, ong.bairro, ong.cidade, ong.uf,
        ong.ativo, ong.dta_cad, ong.telefone_fixo, ong.whatsapp1, ong.whatsapp2,
        ong.facebook, ong.youtube, ong.instagram, ong.twitter 
        FROM tb_organizacao ong 
        WHERE ong.ativo = 1 GROUP BY ong.id_ong";

        $result = formatImages(select($query));

        $response = array("error" => false,  "data" => $result);

    break;

    case "6": // Realiza login da organização

        $fields = ["login", "senha"];

        if(areSet($fields)){
            $dados = json_encode(postData($fields));

            $query = "CALL sp_verificarLogin('$dados')";
            $result = select($query);
            $authenticOng = sizeof($result) == 1;

            $id_ong = false;

            if(sizeof($result) == 1){
                $id_ong = $result[0]->id_ong;
            }
            
            $response = array("error" => $authenticOng ? false : "Login ou senha inválidos",
                              "id_ong" => $id_ong);
        } else {
            $response = array("error" => "Um ou mais parâmetros não foram passados corretamente", "error" => true);
        }
    break;

    case "7": // Verifica se cnpj já foi cadastrado
        $fields = ["cnpj"];

        if(areSet($fields)){
            $dados = postData($fields);

            $query = "SELECT cnpj, id_ong from tb_organizacao WHERE cnpj='$dados->cnpj'";
            $result = select($query);
            $exists = sizeof($result) > 0;
            
            $response = array("result" => $exists, "id_ong"=>($exists)? $result[0]->id_ong : false );
        } else {
            $response = array("error" => "Um ou mais parâmetros não foram passados corretamente", "error" => true);
        }
    break;

    case "8": // Verifica se email já foi cadastrado
        $fields = ["email"];

        if(areSet($fields)){
            $dados = postData($fields);

            $query = "SELECT email, id_ong from tb_organizacao WHERE email='$dados->email'";
            $result = select($query);
            $exists = sizeof($result) > 0;
            
            $response = array("result" => $exists, "id_ong"=>($exists) ? $result[0]->id_ong : false);
        } else {
            $response = array("error" => "Um ou mais parâmetros não foram passados corretamente", "error" => true);
        }
    break;

    case "9": // Verifica se login já foi cadastrado
        $fields = ["login"];

        if(areSet($fields)){
            $dados = postData($fields);

            $query = "SELECT login from tb_organizacao WHERE login='$dados->login'";
            $result = select($query);
            $exists = sizeof($result) > 0;
            
            $response = array("result" => $exists);
        } else {
            $response = array("error" => "Um ou mais parâmetros não foram passados corretamente", "error" => true);
        }
    break;

    case "10": // Atualiza imagem enviada pela organização
        $fields = ["id_imagem", "url", "nome_imagem"];

        if(areSet($fields)){

            $dados = postData($fields);
            $query = "UPDATE tb_imagens SET url='$dados->url', nome_arquivo='$dados->nome_imagem' WHERE id_imagem='$dados->id_imagem'; ";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "11": // Insere imagem enviada pela organização
        $fields = ["url", "nome_imagem", "id_ong"];

        if(areSet($fields)){

            $dados = postData($fields);
            $query = "INSERT INTO tb_imagens(url, nome_arquivo, id_ong) VALUES ('$dados->url', '$dados->nome_imagem', '$dados->id_ong'); ";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "12": // Remove imagem enviada pela organização
        $fields = ["id_imagem", "url"];

        if(areSet($fields)){

            $dados = postData($fields);
            $query = " DELETE FROM tb_imagens WHERE id_imagem='$dados->id_imagem' AND url='$dados->url';";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "13": // Seleciona organização de acordo com query de pesquisa
        $fields = ["query"];
        if(areSet($fields)){
            $dados = postData($fields);
            $query = "CALL sp_searchBar('$dados->query')";
            $result = formatImages(select($query));

            $response = array("error"=>false, "data"=>$result);
        }
    break;

    case "14": // Insere postagem da organização
        $fields = ["id_ong", "titulo", "conteudo"];

        if(areSet($fields)){
            $dados = postData($fields);
            $query = "INSERT INTO tb_postagens(id_ong, titulo, conteudo) VALUES ('$dados->id_ong', '$dados->titulo', '$dados->conteudo')";
            $result = query($query);
            $response = array("error" => ($result === true) ? false : true);

        } else{
            $response = array("error" => true, "errorMsg" => "Um ou mais parâmetros não foram passados corretamente");
        }
    break;

    case "15": // Deleta postagem da organização
    break;

    case "16": // Insere comentário
        $fields = ["id_post", "nome", "email", "comentario"];
        if(areSet($fields)){
            $dados = postData($fields);
            $query = "INSERT INTO tb_comentarios(nome, email, conteudo, id_post) VALUES ('$dados->nome', '$dados->email', '$dados->comentario', '$dados->id_post')";
            $result = query($query);

            $response = array("error"=>false);
        }
    break;

    default:
        $response = array("error" => true, "errorMsg" => "Modo nao encontrado.");
    break;

    case '17': // Envia email de recuperação de senha
        $fields = ["email"];
        if(areSet($fields)){
            $dados = postData($fields);

            $query = "SELECT * FROM tb_organizacao WHERE email='$dados->email'";
            $result = select($query);
            $emailExist = sizeof($result) > 0;

            if($emailExist){
                $query = "SELECT value_senha as senha FROM tb_senhas WHERE id_senha =(SELECT id_senha FROM tb_organizacao WHERE email = '$dados->email')";
                $result = select($query);

                $html = CreateHTMLforEmail($result[0]->senha);

                (SendEmail($dados->email, 'Usuário BeeBetter', 'Recuperação de senha', $html)) ? $response = array("error" => false) : $response = array("error" => "Erro ao enviar email para recuperar senha", "s"=>$result[0]->senha); 

            } else $response = array("success" => false, "error" => "Email nao encontrado");
            

        } else $response = array("error" => "Um ou mais parametros nao foram passados corretamente", "success" => false);
        break;

}

echo json_encode($response);

//Verifica se todos os parâmetros foram recebidos 
function areSet($values){
    $set = true;
    foreach ($values as $value) {
        if(!isset($_REQUEST[$value])){
            $set = false;
            break;
        }
    }
    return $set;
}

//Cria variáveis com base nos parâmetors recebidos
function postData($data = []){
    $object = (object)[];
    foreach ($data as $value) {
        if(isset($_REQUEST[$value])) $object->{$value} = $_REQUEST[$value];
    }
    return (object) $object;
}

//Formata os dados das imagens pra torná-los mais legiveis
function formatImages($result){
    foreach ($result as $i => $resul) {
        $query = "SELECT id_imagem, url as imagem, nome_arquivo as nome_imagem FROM tb_imagens WHERE id_ong = $resul->id_ong";
        $res = select($query);
        $resul->imagens = $res;
        // unset($result[$i]->id_ong);
    }
    return $result;
}

function addComents($results){
    foreach ($results as $i => $result) {
        $query = "SELECT post.id_post, post.titulo, post.conteudo AS postagem, post.dta_post
        FROM tb_organizacao ong LEFT JOIN tb_postagens post ON ong.id_ong = post.id_ong
        WHERE ong.id_ong = $result->id_ong";
        $posts = select($query);
        foreach ($posts as $post) {
            $query = "SELECT coment.id_comentario, coment.nome, coment.conteudo AS comentario, coment.email,
            coment.dta_comentario FROM tb_comentarios coment
            LEFT JOIN tb_postagens post ON
            post.id_post = coment.id_post WHERE coment.id_post = $post->id_post";
            $comments = select($query);
            $post->comments = $comments;
            // unset($post->id_post);
        }
        $result->posts = $posts;
    }
    return $results;
}

    /* ---------- Método de envio de email ---------- */

    function CreateHTMLforEmail($senha){ 

        //Recuperação de senha
            $corpoEmail =  '
            <body bgcolor="#f6f6f6">
                <!-- body -->
                <table class="body-wrap" width="600">
                <tr>
                    <td class="container" bgcolor="#FFFFFF">
                    <!-- content -->
                    <table border="0" cellpadding="0" cellspacing="0" class="contentwrapper" width="600">
                        <tr>
                        <td style="height:25px;">
                            <img src="https://gallery.mailchimp.com/d42c37cf5f5c0fac90b525c8e/images/96288204-f67c-4ba2-9981-1be77c9fa18b.png" border="0" width="600">
                        </td>
                        </tr>
                        <tr>
                        <td>
                            <div class="content">
                            <table class="content-message">
                                <tr>
                                <td>&nbsp;</td>
                                </tr>
                                <tr>
                                <td class="content-message" style="font-family: "Open Sans", "Helvetica Neue", "Helvetica", Calibri, Arial, sans-serif; color: #595959;">
                                    <p>
                                    <img width="51" height="65" border="0" src="https://gallery.mailchimp.com/d42c37cf5f5c0fac90b525c8e/images/940e125b-4079-4193-b880-806bba3b28b3.png"></p>
                                    </p style="color: purple"><h1 style="font-family:"Open Sans"; color: purple">Recuperação de Senha <br> BeBetter</h1></p>
                                    <p style="font-family: "Open Sans","Helvetica Neue", "Helvetica",Calibri, Arial, sans-serif; font-size:18px; line-height:26px;">Estamos lhe enviando sua senha: </p>
                                    <table width="325" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <p><b>'.$senha.'</b></p>
                                    </tr>
                                    </table>
                                    <p style="font-family: "Open Sans","Helvetica Neue", "Helvetica",Calibri, Arial, sans-serif; font-size:18px; line-height:26px;">Se você não solicitou a troca da sua senha BeBetter, ignore esta mensagem.</p>
                                </td>
                                </tr>
                            </table>
                            </div>
                        </td>
                        </tr>
                        <tr>';
     
        
        return $corpoEmail;
    }
    
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    function SendEmail($destinatario, $nomeDest, $assuntoEmail, $conteudoHTML){
    
        require './PHPMailer/src/Exception.php';
        require './PHPMailer/src/PHPMailer.php';
        require './PHPMailer/src/SMTP.php';

        $mail = new PHPMailer;
        $mail->CharSet="UTF-8";
        $mail->isSMTP(); 
        $mail->SMTPDebug = 0; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
        $mail->Host = "smtp.gmail.com"; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
        $mail->Port = 587; // TLS only
        $mail->SMTPSecure = 'tls'; // ssl is depracated
        $mail->SMTPAuth = true;
        $mail->Username = 'fallhealer.nintendo@gmail.com';
        $mail->Password = 'nintendoswitch';
        $mail->setFrom('fallhealer.nintendo@gmail.com', 'Equipe BeeBetter');
        $mail->addAddress($destinatario, $nomeDest);
        $mail->Subject = $assuntoEmail;
        $mail->AltBody = 'HTML messaging not supported';
        $mail->Body = $conteudoHTML; // Conteúdo HTML

        // $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file

        if(!$mail->send()){
           return false;
        }else{
            return true;
        }
    }

?>