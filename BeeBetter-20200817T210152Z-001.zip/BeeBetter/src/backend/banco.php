<?php
	function connection(){

		$con = mysqli_connect("localhost", "root", "root", "sociedade_plus");
		//$con = mysqli_connect("localhost","id12488316_guilherme","gcUu=R*FKBky3B<~", "id12488316_banco_12");

		if(mysqli_connect_errno($con)){
			return $con->connect_error;
		}
		return $con;
	}

	function query($query){
		$con = connection();
		$response = true;
		try{
			if(mysqli_query($con, $query)){
				$response = true;
			} else{
				throw new mysqli_sql_exception(mysqli_errno($con));
			}
		} catch(mysqli_sql_exception $exe){
			$response = $exe->getMessage();
		} finally{
			$con->close();
		}
		return $response;	
	}

	function select($query){
		$con = connection();
		$select = [];
		if($res = mysqli_query($con, $query)){
			while($row = $res->fetch_object()) $select[] = $row;
		}
		$con->close();
		return $select;
	}

	function delete($query){
		$con = connection();
		mysqli_query($con, $query);
		$affectedRows = $con->affected_rows;
		$con->close();
		return $affectedRows;
	}
?>
