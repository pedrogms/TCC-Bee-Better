function ajax(data, mode="404") {

    let newData = '';

    for(const d of Object.keys(data)){
        let formatedData = data[d].replace(' ', '%20');
        newData += `&${d}=${formatedData}`;
    }
    newData += `&mode=${mode}`;

    let urlWebhost = "https://fallhealer.000webhostapp.com/BeeBetter/src/backend/Backend.php";
    let urlLocal = "http://localhost/BeeBetter/src/backend/Backend.php";

      $.ajax({
        async: false,
        method: "POST",
        url: urlLocal,
        data: newData,
        error: () => {
            return false
        }
    }).done(resp => { data = resp; });

    return data;
}

// Verificar backEnd.php para lista detalhada dos modos de operação do banco