create database sociedade_plus DEFAULT character SET utf8 collate utf8_unicode_ci;
use sociedade_plus;

create table tb_senhas(
	id_senha int auto_increment primary key,
	value_senha varchar(50) not null
);

create table tb_organizacao(
	id_ong int auto_increment primary key,
	login varchar(50) not null unique,
	id_senha int not null unique,
	razao_social varchar(50) not null,
    email varchar(50) unique,
    cnpj varchar(20) default null,
    causa_social varchar(50) not null,
    descricao TEXT default null,
    cep varchar(10) not null,
	rua varchar(50) not null,
    numero_residencial varchar(5) not null,
    bairro varchar(50) not null, 
    cidade varchar(50) not null, 
    uf VARCHAR(5),
    ativo bool default true,
    dta_cad datetime default current_timestamp NOT NULL,
    telefone_fixo varchar(12) default null,
    whatsapp1 varchar(12) default null,
    whatsapp2 varchar(12) default null,
    facebook varchar(400) default null,
    youtube varchar(400) default null,
    instagram varchar(400) default null,
    twitter varchar(400) default null,
	foreign key(id_senha) references tb_senhas(id_senha)
);

create table tb_imagens(
	id_imagem int auto_increment primary key,
    url varchar(700) not null,
    nome_arquivo varchar(300) not null,
    id_ong int not null,
    foreign key (id_ong) references tb_organizacao(id_ong)
);

create table tb_adm(
	id_adm int auto_increment primary key,
    login varchar(50) not null,
    id_senha int not null,
    nome varchar(50) not null,
    foreign key(id_senha) references tb_senhas(id_senha)
);

create table tb_postagens(
	id_post int auto_increment primary key,
    id_ong int not null,
    titulo varchar(100) not null,
    conteudo TEXT not null,
    dta_post datetime default current_timestamp not null,
    foreign key(id_ong) references tb_organizacao(id_ong)
);

create table tb_comentarios(
	id_comentario int auto_increment primary key,
    nome varchar(50) not null,
    email varchar(50) not null,
    conteudo TEXT not null, 
    dta_comentario datetime default current_timestamp,
    id_post int not null,
    foreign key(id_post) references tb_postagens(id_post)
);

/* ----- PROCEDURES -----*/

delimiter /
create procedure sp_inserirOng(json_data text)
begin
	SET @login = replace(json_extract(json_data, '$.login'), '"', '');
    SET @senha = replace(json_extract(json_data, '$.senha'), '"', '');
    SET @razao_social = replace(json_extract(json_data, '$.razao_social'), '"', '');
    SET @email = replace(json_extract(json_data, '$.email'), '"', '');
    SET @cnpj = replace(json_extract(json_data, '$.cnpj'), '"', '');
	SET @causa_social = replace(json_extract(json_data, '$.causa_social'), '"', '');
	SET @cep = replace(json_extract(json_data, '$.cep'), '"', '');
    SET @rua = replace(json_extract(json_data, '$.rua'), '"', '');
    SET @numero_residencial = convert(json_extract(json_data, '$.numero_residencial'), signed);
    SET @bairro = replace(json_extract(json_data, '$.bairro'), '"', '');
    SET @cidade = replace(json_extract(json_data, '$.cidade'), '"', '');
    SET @uf = replace(json_extract(json_data, '$.uf'), '"', '');
    
	SET @fone_fixo = replace(json_extract(json_data, '$.foneFixo'), '"', '');
    SET @whatsapp = replace(json_extract(json_data, '$.whatsapp'), '"', '');
    
    SET @img = replace(json_extract(json_data, '$.img'), '"', '');
    SET @nomeImg = replace(json_extract(json_data, '$.nomeImg'), '"', '');
    
    insert into tb_senhas values (DEFAULT, @senha);
    SET @id_senha = (select id_senha from tb_senhas where value_senha = @senha order by id_senha desc limit 1);
    
    insert into tb_organizacao values (DEFAULT, @login, @id_senha, @razao_social, @email, @cnpj, @causa_social, default, @cep, @rua, @numero_residencial, @bairro, @cidade, @uf, default, default, @fone_fixo, @whatsapp, default, default, default, default, default);
	
    SET @id_ong = (select id_ong from tb_organizacao where razao_social=@razao_social and email=@email and login=@login limit 1);
    
    insert into tb_imagens values(default, @img, @nomeImg, @id_ong);
 end/
delimiter $


delimiter /
create procedure sp_alterarOng(json_data text)
begin
	SET @id = replace(json_extract(json_data, '$.id'), '"', '');
	
    SET @razao_social = replace(if(json_extract(json_data, '$.razao_social') <> "", json_extract(json_data, '$.razao_social'), (select razao_social from tb_organizacao where id_ong = @id)), '"', '');
    SET @senha = replace(if(json_extract(json_data, '$.senha') <> "", json_extract(json_data, '$.senha'), (select value_senha from tb_senhas where id_senha = (select id_senha from tb_organizacao where id_ong = @id))), '"', '');
	SET @email = replace(if(json_extract(json_data, '$.email') <> "", json_extract(json_data, '$.email'), (select email from tb_organizacao where id_ong = @id)), '"', '');
	SET @ativo = replace(if(json_extract(json_data, '$.ativo') <> "", json_extract(json_data, '$.ativo'), (select ativo from tb_organizacao where id_ong = @id)), '"', '');
	
    SET @cnpj = replace(json_extract(json_data, '$.cnpj'), '"', '');
	SET @causa_social = replace(if(json_extract(json_data, '$.causa_social') <> "", json_extract(json_data, '$.causa_social'), (select causa_social from tb_organizacao where id_ong = @id)), '"', '');
    
	
    SET @cep = replace(if(json_extract(json_data, '$.cep') <> "", json_extract(json_data, '$.cep'), (select cep from tb_organizacao where id_ong = @id)), '"', '');
    SET @rua = replace(if(json_extract(json_data, '$.rua') <> "", json_extract(json_data, '$.rua'), (select rua from tb_organizacao where id_ong = @id)), '"', '');
    SET @numero_residencial = replace(if(json_extract(json_data, '$.numero_residencial') <> "", json_extract(json_data, '$.numero_residencial'), (select numero_residencial from tb_organizacao where id_ong = @id)), '"', '');
    SET @bairro = replace(if(json_extract(json_data, '$.bairro') <> "", json_extract(json_data, '$.bairro'), (select bairro from tb_organizacao where id_ong = @id)), '"', '');
    SET @cidade = replace(if(json_extract(json_data, '$.cidade') <> "", json_extract(json_data, '$.cidade'), (select cidade from tb_organizacao where id_ong = @id)), '"', '');
    SET @uf = replace(if(json_extract(json_data, '$.uf') <> "", json_extract(json_data, '$.uf'), (select uf from tb_organizacao where id_ong = @id)), '"', '');
    
    SET @telefone_fixo = replace(json_extract(json_data, '$.telefone_fixo'), '"', '');
	SET @whatsapp1 = replace(json_extract(json_data, '$.whatsapp1'), '"', '');
    SET @whatsapp2 = replace(json_extract(json_data, '$.whatsapp2'), '"', '');
	SET @facebook = replace(json_extract(json_data, '$.facebook'), '"', '');
	SET @youtube = replace(json_extract(json_data, '$.youtube'), '"', '');
	SET @instagram = replace(json_extract(json_data, '$.instagram'), '"', '');
	SET @twitter = replace(json_extract(json_data, '$.twitter'), '"', '');
    
    update tb_senhas SET value_senha=@senha where id_senha=(select id_senha from tb_organizacao where id_ong=@id);
    
    update tb_organizacao set
		razao_social = @razao_social, email = @email,
        cnpj = @cnpj, causa_social = @causa_social,
        cep = @cep, rua = @rua, numero_residencial = @numero_residencial, bairro = @bairro, cidade = @cidade, uf = @uf,
        telefone_fixo = @telefone_fixo, whatsapp1 = @whatsapp1, whatsapp2 = @whatsapp2, 
        facebook = @facebook, youtube = @youtube, instagram = @instagram, twitter = @twitter, ativo = @ativo
        where id_ong=@id;
 end/
delimiter $


delimiter /
create procedure sp_verificarLogin(json_data text)
begin
	SET @login = replace(json_extract(json_data, '$.login'), '"', "");
	SET @senha = replace(json_extract(json_data, '$.senha'), '"', "");
    
    SELECT id_ong FROM tb_organizacao INNER JOIN tb_senhas ON tb_organizacao.id_senha = tb_senhas.id_senha 
    WHERE tb_organizacao.login = @login AND tb_senhas.value_senha = @senha;
 end/
delimiter $


delimiter /
create procedure sp_pesquisarOng(id_ong int)
begin

	select ong.id_ong, ong.razao_social, ong.email, ong.cnpj, ong.descricao, ong.causa_social,
			ong.cep, ong.rua, ong.numero_residencial, ong.bairro, ong.cidade, ong.uf,
            ong.ativo, ong.dta_cad, ong.telefone_fixo,
			ong.whatsapp1, ong.whatsapp2, ong.facebook, ong.youtube, ong.instagram, ong.twitter,  
			se.value_senha
			from tb_organizacao ong inner join tb_senhas se on ong.id_senha = se.id_senha
			where ong.id_ong = id_ong;
    
 end/
delimiter $

 delimiter /
create procedure sp_searchBar(search text)
begin
	SELECT ong.id_ong, ong.razao_social, ong.email, ong.cnpj, ong.descricao, ong.causa_social,
        ong.cep, ong.rua, ong.numero_residencial, ong.bairro, ong.cidade, ong.uf,
        ong.ativo, ong.dta_cad, ong.telefone_fixo, ong.whatsapp1, ong.whatsapp2,
        ong.facebook, ong.youtube, ong.instagram, ong.twitter
        FROM tb_organizacao ong
        WHERE ong.ativo = 1 and (ong.razao_social like concat('%', search, '%')
        or ong.descricao like concat('%', search, '%') or ong.cidade like concat('%', search, '%')
        or ong.rua like concat('%', search, '%') or ong.bairro like concat('%', search, '%')
		or ong.causa_social like concat('%', search, '%')
        );
end/
 
delimiter $


/*insert into tb_senhas values(default, '123456');
insert into tb_organizacao values(default, 'login2', 5, 'razao', 'email2', 111,'Assitência Financeira é','
	The MEDIUMTEXT can hold up to 16MB text data that is equivalent to 16,777,215 characters. It requires 3 bytes overhead.

The MEDIUMTEXT is useful for storing quite large text data like the text of a book, white papers, etc. For example:
', 1, 'rua', 1, 'bairro', 'cdidade', 'UF', default, default, default, default, default, default, default, default, default);
insert into tb_imagens values(default, 'url', 'nome', '5');*/

call sp_pesquisarOng(1);
